#!/bin/bash
#############################################################################
#
# Copyright (C) 2005 Marcos Nobre - 06/09/2005
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
# localizar_arquivo_dat.sh - busca e desempacota um arquivo, em Fita DAT de
# arquivamento do SPED
# 
# por: Marcos Aurelio Nobre  <marconobre@gmail.com>, em 06/09/2005.
# ultima revisao : 12.09.2005                  
#                  21:15:00    
# LayOut: dispositivo_recuperacao.txt
# n,n,n > arq.sped > arq_procurado > archive_num
#############################################################################

function verificaFN
{
    rm -rf /tmp/erro.txt > /dev/null 2>&1
    x=`mt -f $ftDAT rewind > /dev/null 2>&1`
    x=`mt -f $ftDAT asf $file_number 1> /dev/null 2> /tmp/erro.txt`
    if [ -f /tmp/erro.txt ]; then
       x=`cat /tmp/erro.txt | cut -f 2 -d:`
       if [ "$x" = " Input/output error" ]; then
	    echo -e "Numero de Archive (File Number):$file_number nao encontrado nesta Fita." > $path/info/problema_localizacao_msg.txt
	    echo -e "-1" > $path/info/problema_localizacao.txt
	    exit 1
       fi
    fi
}

function desmontaTUDO
{
# Desmontar todas as particoes caso o usuario tenha esquecido... ;)
while read x mnt x
do
    case "$mnt" in
            /mnt*)
                umount $mnt > /dev/null 2>&1
                ;;
            *) ;;
    esac
done < /proc/mounts 
umount /mnt/cd* > /dev/null 2>&1                                  
}


## -------------------------------- SPED -----------------------------------
path="/usr/local/jakarta-tomcat-5.5.9/webapps/sped/scripts"
origem="$path/arquivamento/"

desmontaTUDO

rm -rf /tmp/erro.txt > /dev/null 2>&1
rm -rf /tmp/ok.txt > /dev/null 2>&1
rm -rf $path/info/problema_localizacao_msg.txt >/dev/null 2>&1
rm -rf $path/info/problema_localizacao.txt > /dev/null 2>&1

cd $path/progs
## -------------------------------- SPED -----------------------------------


##########################################################
## Verifica arquivo de informacao de Dispositivo/Pesquisa
## -------------------------------------------------------
if [ ! -f $path/info/dispositivo_recuperacao.txt ]; then
    echo -e "Problema: arquivo $path/info/dispositivo_recuperacao.txt nao encontrado." > $path/info/problema_localizacao_msg.txt
    echo -e "-1" > $path/info/problema_localizacao.txt
    exit 1
fi

disp=`cat $path/info/dispositivo_recuperacao.txt | cut -f 1 -d\>`
disp=`echo -e "$disp" | cut -f 1 -d\ `

arq_sped=`cat $path/info/dispositivo_recuperacao.txt | cut -f 2 -d\>`
arq_sped=`echo -e "$arq_sped" | cut -f 2 -d\ `

arq_searched=`cat $path/info/dispositivo_recuperacao.txt | cut -f 3 -d\>`
arq_searched=`echo -e "$arq_searched" | cut -f 2 -d\ `

file_number=`cat $path/info/dispositivo_recuperacao.txt | cut -f 4 -d\>`
file_number=`echo -e "$file_number" | cut -f 2 -d\ `

ftDAT="/dev/n$disp"

export ftDAT arq_sped arq_searched file_number path
   
   rm -rf /tmp/erro.txt > /dev/null 2>&1
   rm -rf /tmp/ok.txt > /dev/null 2>&1
   
   #################################################
   ## Checa se o drive e a midia estao em ordem
   ## ----------------------------------------------
   status=`mt -f $ftDAT status | tail -1`
   erro=`echo -n $status | grep "DR_OPEN"`
   if [ "$erro" != "" ]; then     
      echo -e "Erro: DR_OPEN Porta aberta ou dispositivo sem midia." > $path/info/problema_localizacao_msg.txt
      echo -e "-1" > $path/info/problema_localizacao.txt
      exit 1
   fi
   
   erro=`echo -n $status | grep "WR_PROT"`
   if [ "$erro" != "" ]; then     
      echo -e "Erro: WR_PROT Dispositivo ou Midia nao suporta gravacao." > $path/info/problema_localizacao_msg.txt
      echo -e "-1" > $path/info/problema_localizacao.txt
      exit 1
   fi
      
   #################################################
   ## Checa se o FN eh valido para a Fita colocada
   ## ----------------------------------------------
   verificaFN    
      
   #################################################
   ## Posiciona no File Number informado
   ## ----------------------------------------------
   mt -f $ftDAT rewind > /dev/null 2>&1
   # isso:
   mt -f $ftDAT asf $file_number
   # ou isso:
#   fnumber=0
#   if [ "$file_number" -gt 0 ]; then
#	while mt -f $ftDAT fsf 1 > /dev/null 2>&1 
#	do
#	    sleep 2   
#	    #virgem=`mt -f $ftDAT status | grep "^File"`
#	    #file_number=`echo -n $virgem | cut -f1 -d\, `
#	    #file_number=`echo -n $file_number | cut -f2 -d\= `
#	    #block_number=`echo -n $virgem | cut -f2 -d\, `
#	    #block_number=`echo -n $block_number | cut -f2 -d\= `
#	    #partition=`echo -n $virgem | cut -f3 -d\, `
#	    #partition=`echo -n $partition | cut -f2 -d\= `
#	    fnumber=`expr $fnumber + 1`
#	    if [ "$file_number" -eq $fnumber ]; then
#		break
#	    fi
#	done
#   fi
#echo -e "$disp"
#echo -e "$arq_sped"
#echo -e "$arq_searched"
#echo -e "$file_number"
#echo -e "fnumber = $fnumber"
#exit 0
   
################################################################
## Lista todos os nomes de arquivos do Archive informado
## -------------------------------------------------------------
arquivosDAT=`tar -tvf $ftDAT`

################################################################
## Checa se Arquivo compactado esta no CD
## -------------------------------------------------------------
estah=`echo -e $arquivosDAT | grep "$arq_sped"`
if [ "$estah" = "" ]; then
      echo -e "Arquivo $arq_sped nao encontrado no FN: $file_number da FITA." > $path/info/problema_localizacao_msg.txt
      echo -e "-1" > $path/info/problema_localizacao.txt
      exit 1
fi

################################################################
## Descompacta arq_sped para achar arq_searched
## -------------------------------------------------------------
if [ ! -d /tmp/recup ]; then
	mkdir /tmp/recup
fi

rm -rf /tmp/recup/*
rm -rf $path/arquivamento/*

### Reposiciona novamente
x=`mt -f /dev/$ftDAT rewind > /dev/null 2>&1`
### Posiciona (de forma absoluta) no FN desejado
x=`mt -f /dev/nst0 asf $file_number`
### Copia o pacote, da Fita para HD
x=`tar -xPvf $ftDAT > /dev/null 2>&1`
unzip $path/arquivamento/$arq_sped -d /tmp/recup/ > /dev/null 2>&1

################################################################
## Checa se Arquivo_Searched esta no conteudo compactado
## -------------------------------------------------------------
#estah=`ls -1R /tmp/recup/ | grep "$arq_searched"`
#if [ "$estah" = "" ]; then
#      echo -e "Arquivo $arq_searched nao encontrado no arquivo $arq_sped." > $path/info/problema_localizacao_msg.txt
#      echo -e "-1" > $path/info/problema_localizacao.txt
#      exit 1
#fi

DISPLAY=:0.0
export DISPLAY
/usr/bin/mozilla -remote "openurl(file:///tmp/recup,new-tab)" &

exit 0  

################################################################
# ----------------------------End ------------------------------ 
################################################################  
  
  


