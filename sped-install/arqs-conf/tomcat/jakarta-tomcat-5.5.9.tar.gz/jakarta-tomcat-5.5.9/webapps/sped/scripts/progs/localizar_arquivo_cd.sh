#!/bin/bash
#############################################################################
#
# Copyright (C) 2005 Marcos Nobre - 06/09/2005
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
# localizar_arquivo_cd.sh - busca e desempacota um arquivo, em CD de
# arquivamento do SPED
# 
# por: Marcos Aurelio Nobre  <marconobre@gmail.com>, em 06/09/2005.
# ultima revisao: 12.09.2005
#                 21:15:00                
# LayOut: dispositivo_recuperacao.txt
# n,n,n > arq.sped > arq_procurado
#############################################################################

## -------------------------------- SPED -----------------------------------
path="/usr/local/jakarta-tomcat-5.5.9/webapps/sped/scripts"
origem="$path/arquivamento/"
cd $path/progs
# Desmontar todas as particoes caso o usuario tenha esquecido... ;)
while read x mnt x
do
    case "$mnt" in
        /mnt*)
	    umount $mnt > /dev/null 2>&1
	    ;;
	*) ;;
    esac
done < /proc/mounts 
umount /mnt/cd* > /dev/null 2>&1				  
				  
rm -rf $path/info/problema_localizacao_msg.txt >/dev/null 2>&1
rm -rf $path/info/problema_localizacao.txt > /dev/null 2>&1
rm -rf /tmp/erro.txt > /dev/null 2>&1
rm -rf /tmp/ok.txt > /dev/null 2>&1
## -------------------------------- SPED -----------------------------------

##########################################################
## Verifica arquivo de informacao de Dispositivo/Pesquisa
## -------------------------------------------------------
if [ ! -f $path/info/dispositivo_recuperacao.txt ]; then
	echo -e "Problema: arquivo $path/info/dispositivo_recuperacao.txt nao encontrado." > $path/info/problema_localizacao_msg.txt
	echo -e "-1" > $path/info/problema_localizacao.txt
	exit 1
fi

disp=`cat $path/info/dispositivo_recuperacao.txt | cut -f 1 -d\>`
disp=`echo -e "$disp" | cut -f 1 -d\ `

################################################################
##      "Pega" o nome do dispositivo e monta
## -------------------------------------------------------------      
rm -rf /tmp/erro.txt > /dev/null 2>&1
rm -rf /tmp/ok.txt > /dev/null 2>&1
 
if [ "$disp" = "0,0,0" ]; then
   cdrom="cdrom"
fi
  
if [ "$disp" = "0,1,0" ]; then
   cdrom="cdrom1"
fi
   
x=`mount /dev/$cdrom 2>/tmp/erro.txt 1>/tmp/ok.txt`
   
erro=`cat /tmp/erro.txt`   
if [ "$erro" != "" ]; then
      echo -e "Problema com a Identificacao do CDROM" > $path/info/problema_localizacao_msg.txt
      echo -e "-1" > $path/info/problema_localizacao.txt
      exit 1
fi

arq_sped=`cat $path/info/dispositivo_recuperacao.txt | cut -f 2 -d\>`
arq_sped=`echo -e "$arq_sped" | cut -f 2 -d\ `
arq_searched=`cat $path/info/dispositivo_recuperacao.txt | cut -f 3 -d\>`
arq_searched=`echo -e "$arq_searched" | cut -f 2 -d\ `

################################################################
## Lista todos os nomes de arquivos do CDROM
## -------------------------------------------------------------
arquivosCD=`ls -1 /mnt/$cdrom`

################################################################
## Checa se Arquivo compactado esta no CD
## -------------------------------------------------------------
estah=`echo -e $arquivosCD | grep "$arq_sped"`
if [ "$estah" = "" ]; then
      echo -e "Arquivo $arq_sped nao encontrado no CD." > $path/info/problema_localizacao_msg.txt
      echo -e "-1" > $path/info/problema_localizacao.txt
      exit 1
fi

########################
# Alterei para criar uma vari�vel com o diret�rio de descompacta��o
# Coloquei ele dentro do diret�rio 'webapps/sped' para alterar a
# estrat�gia de recupera��o no que diz respeito a abrir a janela
# do navegador com a lista dos arquivos descompactados.
# Ficava dando aquele erro 'No running window found'.
# Ricardo - Mirante

dir_recup=../../temp/recup/

################################################################
## Descompacta arq_sped para achar arq_searched
## -------------------------------------------------------------
if [ ! -d "$dir_recup" ]; then
	mkdir $dir_recup
fi
rm -rf "$dir_recup"*
unzip /mnt/$cdrom/$arq_sped -d $dir_recup

################################################################
## Checa se Arquivo_Searched esta no conteudo compactado
## -------------------------------------------------------------
#estah=`ls -1 $dir_recup | grep "$arq_searched"`
#if [ "$estah" = "" ]; then
#      echo -e "Arquivo $arq_searched nao encontrado no arquivo $arq_sped." > $path/info/problema_localizacao_msg.txt
#      echo -e "-1" > $path/info/problema_localizacao.txt
#      exit 1
#fi

##browser=`/usr/bin/mozilla file://$dir_recup  &&`
##browser=`kfmclient openProfile webbrowsing file://$dir_recup ;`

DISPLAY=:0.0
export DISPLAY

################
# Comentei tudo isso aqui porque ficava dando aquele erro:
# "No running window found".
# Mudei a estrat�gia pro pr�prio JSP chamar outra janela apontando
# pro diret�rio de recupera��o ($dir_recup)
# Ricardo - Mirante

#/usr/bin/mozilla-firefox -remote "openurl(file://$dir_recup,new-tab)" &
#/usr/bin/mozilla -remote "openurl(file://$dir_recup,new-tab)" &

exit 0  

################################################################
# ----------------------------End ------------------------------ 
################################################################  
  
  


