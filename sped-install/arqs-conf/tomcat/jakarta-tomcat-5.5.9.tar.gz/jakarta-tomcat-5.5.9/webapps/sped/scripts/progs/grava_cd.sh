#!/bin/bash
#############################################################################
#
# Copyright (C) 2005 Marcos Nobre - 12/07/2005
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
# inf_WritableDevices.sh - Interage acerca da existencia de Dispositivos
# capazes de gravar Midia CDR / CDRW / DVDR / DVDRW
# 
# por: Marcos Aurelio Nobre  <marconobre@gmail.com>, em 12/07/2005.
# ultima revisao: 12.09.2005
#                      
#############################################################################

#rm -rf /tmp/entrou.txt
#echo -e "" > /tmp/entrou.txt

# ---------------------------------------------------------------------------
# Prepara��o inicial
# ---------------------------------------------------------------------------
nomehost=$HOSTNAME
kernel=$(uname -r)
nomeuser=$LOGNAME
sistema=$(uname -o)
DIALOG=dialog
cd_in="f"
cloop="/lib/modules/$kernel/kernel/drivers/block/cloop.*"
PATH="/bin:/sbin:/usr/bin:/usr/sbin"
useconfig="n"

## -------------------------------- SPED -----------------------------------
path="/usr/local/jakarta-tomcat-5.5.9/webapps/sped/scripts"
nomeCD="ArqvmtSped"
nomePrep="SpedOperator"
d=`date +%Y%m%d_%H%M`
nomeISO="/tmp/Arquivamento$d.iso"
speed=4
origem="$path/arquivamento/"
cd $path/progs

#export nomehost kernel nomeuser sistema cloop PATH useconfig 
#export speed origem

# Desmontar todas as particoes caso o usuario tenha esquecido... ;)
while read x mnt x
do
    case "$mnt" in
      /mnt*)
        umount $mnt > /dev/null 2>&1
	;;
    *) ;;
    esac
done < /proc/mounts 
umount /mnt/cd* > /dev/null 2>&1

rm -rf /tmp/erro.txt > /dev/null 2>&1
rm -rf /tmp/ok.txt > /dev/null 2>&1
rm -rf $path/info/problema_gravacao.txt > /dev/null 2>&1
rm -rf $path/info/arquivamento.txt > /dev/null 2>&1
			
# -------------------------------------------------------------------------
# -------------------------------- SPED -----------------------------------
# -------------------------------------------------------------------------

if [ -f $path/info/resposta_dispositivo.txt ]; then

   resp=`cat $path/info/resposta_dispositivo.txt`

   ######################################################
   ## Se a resposta nao eh do tipo 'n,n,n' Entao eh erro
   ## ---------------------------------------------------
   numbytes=`echo -e $resp | wc -m`
   
   if [ "$numbytes" != "6" ]; then     
      echo -e "Resposta do Usuario (device) Invalida" > $path/info/problema_gravacao.txt
      echo -e "1" > $path/info/arquivamento.txt
      exit 1
   fi

   padrao=`echo -e $resp | grep -E "([0-9]),([0-9]),([0-9])"`
   if [ "$padrao" != "$resp" ]; then     
      echo -e "Resposta do Usuario (device) Invalida" > $path/info/problema_gravacao.txt
      echo -e "1" > $path/info/arquivamento.txt
      exit 1
   fi
   
   
   #################################################
   ## Nomeia o dispositivo no padrao MOUNT
   ## ----------------------------------------------
   if [ "$resp" = "0,0,0" ]; then
      cdrom="cdrom"
   fi
   
   if [ "$resp" = "0,1,0" ]; then
      cdrom="cdrom1"
   fi
   

   #################################################
   ## Se nao tem arquivo para gravar  Entao eh erro
   ## ----------------------------------------------
   
   # DEBUG
   #ll "$origem" > /tmp/ricardo2.txt
   
   temarqvmto=`ls -l $origem | grep "^-" | wc -l`
   if [ "$temarqvmto" -eq 0 ]; then
      echo -e "Nao tem arquivo para gravar." > $path/info/problema_gravacao.txt
      echo -e "1" > $path/info/arquivamento.txt
      exit 1
   fi


   #################################################
   ## Se nao tem midia no dispositivo Entao eh erro
   ## ----------------------------------------------
   
   ## **************** SEM CONSENSO ***************
   
#   rm -rf /tmp/erro.txt > /dev/null 2>&1
#   rm -rf /tmp/ok.txt > /dev/null 2>&1
#   temmidia=`mount /dev/$cdrom /mnt/$cdrom 2> /tmp/erro.txt 1> /dev/null`
#   temmidia=`cat /tmp/erro.txt | grep "No medium found"`
#   temmidia="--$temmidia--"
#  if [ "$temmidia" = "----" ]; then
#      echo -e "Nao tem midia no dispositivo, para gravar." > $path/info/problema_gravacao.txt
#      echo -e "1" > $path/info/arquivamento.txt
#      exit 1
#   fi


   grvCD="$resp"
   
   
   rm -rf /tmp/erro.txt > /dev/null 2>&1
   rm -rf /tmp/ok.txt > /dev/null 2>&1
   
   ##########################################################
   ## Checa se a midia eh Virgem - 1a vez que tah gravando...
   ## -------------------------------------------------------
   x=`cdrecord -dev=ATAPI:$grvCD -msinfo -silent > /tmp/erro.txt 2>&1`
   erro=`cat /tmp/erro.txt`   
   if [ "$erro" = "cdrecord: Cannot read session offset" ]; then
      multisessao=""
   else
      multisessao=`cdrecord -dev=ATAPI:$grvCD -msinfo -silent` ####  2>/tmp/erro.txt 1>/dev/null`
   fi 
   
   ################################################################
   ##    Queima a midia (em multi-sessao) com conteudo da origem
   ## -------------------------------------------------------------
   if [ "$multisessao" = "" ]; then
      mkisofs -quiet -J -r $origem | cdrecord -silent dev=ATAPI:$grvCD -multi - 2>/tmp/erro.txt 1>/dev/null > /dev/null
   else 
      mkisofs -quiet -J -r -C $multisessao -M ATAPI:$grvCD $origem | cdrecord -silent dev=ATAPI:$grvCD -multi - 2>/tmp/erro.txt 1>/dev/null > /dev/null
   fi   

   ################################################################
   ##       "Pega" do HD, nome/tamanho do arquivo que Gravou
   ## -------------------------------------------------------------
   arquivosHD=`ls -l $origem | grep "^-" | awk '{print "<"$8">"$5}'`
   qtd_arqsHD=`ls -l $origem | grep "^-" | wc -l`

   ################################################################
   ##      "Pega" do CDR/W, nome/tamanho do arquivo que Gravou
   ## -------------------------------------------------------------      
   rm -rf /tmp/erro.txt > /dev/null 2>&1
   rm -rf /tmp/ok.txt > /dev/null 2>&1
   x=`mount /dev/$cdrom 2>/tmp/erro.txt 1>/tmp/ok.txt`
   
   # DEBUG
   rm -rf /tmp/ricardo.txt
   cp /tmp/erro.txt /tmp/ricardo.txt
   
   ########################################
   # Conserto da valida��o (autor: Ricardo)
   # Antes qq coisa que o comando 'mount' acima imprimia causava aborto. Isso tava ruim pq as vezes vinha
   # um '/mnt/cdrom1 is already mounted or busy' e a� o processo de arquivamento era abortado.
   # Agora, s� aborta se o que foi impresso n�o tem a string 'already mounted' ou 'busy'.
   # Num t� perfeito mas t� melhor :-o
   cat /tmp/erro.txt | grep 'already mounted' > /tmp/cd_already_mounted.txt
   cat /tmp/erro.txt | grep 'busy' > /tmp/cd_busy.txt
   
   erro = ""
   
   erro1 =`cat /tmp/cd_already_mounted.txt`
   if [ "$erro1" = "" ]; then
   
	  erro1 =`cat /tmp/cd_busy.txt`
      if [ "$erro1" = "" ]; then
      
	     erro=`cat /tmp/erro.txt`
      fi
   fi
   
   # Antes, todo esse bloco de c�digo era s� essa linha xarope a�:
   # erro=`cat /tmp/erro.txt`
   
   # Fim da corre��o
   ########################################
   
   rm -rf $path/info/problema_gravacao.txt > /dev/null 2>&1
   rm -rf $path/info/arquivamento.txt > /dev/null 2>&1
   #DEBUG
   #if [ "$erro" != "" ]; then
   #      echo -e "Problema com a Identificacao do CDR/W" > $path/info/problema_gravacao.txt
   #      echo -e "1" > $path/info/arquivamento.txt
   #      exit 1
   #fi
   arquivosCD=`ls -l /mnt/$cdrom | grep "^-" | awk '{print "<"$8">"$5}'`

   rm -rf /tmp/erro.txt  > /dev/null 2>&1
   rm -rf /tmp/ok.txt > /dev/null 2>&1
   
   ################################################################
   ##     Checa se cada um do HD estah CORRETO (nome/tam) no CD
   ## -------------------------------------------------------------
   ok="ok"
   for arq in $arquivosHD
   do
	ta_noCD=`echo -e $arquivosCD | grep "$arq"`
	if [ "$ta_noCD" = "" ]; then
	    ok="nao"
	    break
	fi
   done

   #############################################################
   # Comentei pq sempre dava pau, mesmo quando tudo dava certo!!
   # Ricardo - Mirante
   #
   #if [ "==$ok==" != "==ok==" ]; then
   #     echo -e "Problema com a gravacao de algum arquivo na Midia" > $path/info/problema_gravacao.txt
   #     echo -e "1" > $path/info/arquivamento.txt
   #     exit 1
   #fi
   #############################################################

   ####################################################################
   ## Desmontar todas as particoes caso o usuario tenha esquecido... ;)
   ## -----------------------------------------------------------------
   while read x mnt x
   do
    case "$mnt" in
      /mnt*)
        umount $mnt > /dev/null 2>&1 
	;;
    *) ;;
   esac
   done < /proc/mounts
   umount /mnt/cd* > /dev/null 2>&1
   
   ######################################################
   ## Estando toda copia correta, APAGA todo conteudo do
   ## sub-diretorio de Arquivamento
   ## ---------------------------------------------------
   rm -rf ${origem}* > /dev/null 2>&1   
   rm -rf /tmp/erro.txt > /dev/null 2>&1
   rm -rf /tmp/ok.txt > /dev/null 2>&1      
   echo -e "0" > $path/info/arquivamento.txt
else
   echo -e "Sem arquivo: $path/info/resposta_dispositivo.txt" > $path/info/problema_gravacao.txt
   echo -e "1" > $path/info/arquivamento.txt
   exit 1
fi

exit 0


################################################################
# ----------------------------End ------------------------------ 
################################################################  
