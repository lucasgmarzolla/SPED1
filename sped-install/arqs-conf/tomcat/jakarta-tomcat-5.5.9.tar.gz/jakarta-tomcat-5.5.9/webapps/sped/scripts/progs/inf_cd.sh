#!/bin/bash
#############################################################################
#
# Copyright (C) 2005 Marcos Nobre - 07/07/2005
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
# inf_WritableDevices.sh - Interage acerca da existencia de Dispositivos
# capazes de gravar Midia CDR / CDRW / DVDR / DVDRW
# 
# por: Marcos Aurelio Nobre  <marconobre@gmail.com>, em 07/07/2005.
#                      
#############################################################################


# ------------------
# Prepara��o inicial
# ------------------
path="/usr/local/jakarta-tomcat-5.5.9/webapps/sped/scripts"
nomehost=$HOSTNAME
kernel=$(uname -r)
nomeuser=$LOGNAME
sistema=$(uname -o)
DIALOG=dialog
cd_in="f"
cloop="/lib/modules/$kernel/kernel/drivers/block/cloop.*"
PATH="/bin:/sbin:/usr/bin:/usr/sbin"
useconfig="n"

#export nomehost kernel nomeuser sistema cloop PATH useconfig 
# -----------------------------------------------------------

rm -rf $path/info/dispositivos_CD.txt >/dev/null 2>&1
rm -rf /tmp/grvcds.txt > /dev/null 2>&1

# ---------------------------------------
## Se existe arquivo dispositivos_CD.txt, ja
## foram identificados e simplesmente sai
# ---------------------------------------
#if [ -f $path/info/dispositivos_CD.txt ]; then
#   exit 0
#fi

# ---------------------------------
# Testa a existencia de CDR ou CDRW
# ---------------------------------
# O pressuposto eh que o equipamento tera no maximo 2 drivers
# de CDx, sob qualquer combinacao (CDROM + CDR / CDR + CDROM)
soh_CD="CD"
tem_writable_dev="0"
cdrws=`cat /proc/sys/dev/cdrom/info | grep "Can write $soh_CD" | awk '/Can/{print $3$4$5}'`
for drvs in $cdrws
do
   tem=`echo $drvs | cut -f2 -d:`
   ## se o unico driver de CD eh gravavel
   if [ "$tem" = "1" ]; then
      tem_writable_dev="1"
      break
   fi
   ## se o 1o. de dois drivers de CD, eh gravavel
   if [ "$tem" = "10" ]; then
      tem_writable_dev="1"
      break
   fi
   ## se o 2o. de dois drivers de CD, eh gravavel
   if [ "$tem" = "01" ]; then
      tem_writable_dev="1"
      break
   fi
done
if [ "$tem_writable_dev" = "0" ]; then
  ##$DIALOG --title " ATENCAO !!! " --msgbox "\nNao foi encontrado algum dispositivo capaz de gravar dados em midia CD.\nA tarefa CANCELADA!"  8 75
  ##$DIALOG --infobox "\nNao foi encontrado algum dispositivo capaz de gravar dados em midia CD.\nTarefa CANCELADA!"  8 75
  rm -rf $path/info/dispositivos_CD.txt  > /dev/null 2>&1
  exit 0
fi

# --------------------------------
# Enumera CDRs ou CDRWs existentes
# --------------------------------
  
  ## Rastreamento...  
  cdrecord -dev=ATAPI -scanbus > /tmp/grvcds.txt 2>&1
  
  ## A priori, verifica se alguma de duas unidades de cdrom
  ## eh r/w
  if [ `grep 0,0,0 /tmp/grvcds.txt | cut -f2` ]; then
     unid1="0,0,0"
     disp1=`grep 0,0,0 /tmp/grvcds.txt | cut -f3`
     achou1=`grep 0,0,0 /tmp/grvcds.txt | cut -f2 -d ")"`
  else
     unset unid1
     achou1=" *"
  fi
   
  if [ `grep 0,1,0 /tmp/grvcds.txt | cut -f2` ]; then
     unid2="0,1,0"
     disp2=`grep 0,1,0 /tmp/grvcds.txt | cut -f3`
     achou2=`grep 0,1,0 /tmp/grvcds.txt | cut -f2 -d ")"`
  else
     unset unid2
     achou2=" *"
  fi
  
  if [ "$achou1$achou2" = " * *" ]; then  
     if [ -f $path/info/dispositivos_CD.txt ]; then 
        rm -rf $path/info/dispositivos.txt
     fi     
     ## $DIALOG --msgbox "Nao foi encontrada alguma unidade de CD-RW para realizar a tarefa." 8 75
     rm -rf $path/info/dispositivos_CD.txt >/dev/null 2>&1 
     exit 0
  fi
  
  if [ "$unid1$unid2" != "" ]; then
  
     ##grvCD=$($DIALOG --stdout --title "Escolha o Gravador de CD" \
     ##--menu "\n\nEscolha que gravador de CD deseja usar gravacao de dados:\n\n" 12 75 2    $unid1 "$disp1" $unid2 "$disp2")

     if [ "$achou1" != " *" ]; then
        echo -e "$unid1 >$achou1" > $path/info/dispositivos_CD.txt
     fi
     
     if [ "$achou2" != " *" ]; then
        echo -e "$unid2 >$achou2" >> $path/info/dispositivos_CD.txt
     fi     
     exit 0
  else
     #if [ -f $path/info/dispositivos_CD.txt ]; then 
        rm -rf $path/info/dispositivos_CD.txt >/dev/null 2>&1
     #fi
     exit 0
  fi
  
################################################################
# ----------------------------End ------------------------------ 
################################################################  
  
  


