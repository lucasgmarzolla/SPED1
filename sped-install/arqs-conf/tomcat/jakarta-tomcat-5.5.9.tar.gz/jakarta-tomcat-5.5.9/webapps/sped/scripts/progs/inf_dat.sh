#!/bin/bash
#############################################################################
#
# Copyright (C) 2005 Marcos Nobre - 07/07/2005
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
# inf_FitaDat.sh - Interage acerca da existencia de Dispositivos
# de FITA
# 
# por: Marcos Aurelio Nobre  <marconobre@gmail.com>, em 22/08/2005.
#                      
#############################################################################


# ------------------
# Prepara��o inicial
# ------------------
path="/usr/local/jakarta-tomcat-5.5.9/webapps/sped/scripts"
nomehost=$HOSTNAME
kernel=$(uname -r)
nomeuser=$LOGNAME
sistema=$(uname -o)
DIALOG=dialog
cd_in="f"
cloop="/lib/modules/$kernel/kernel/drivers/block/cloop.*"
PATH="/bin:/sbin:/usr/bin:/usr/sbin"
useconfig="n"

#export nomehost kernel nomeuser sistema cloop PATH useconfig 
# -----------------------------------------------------------

rm -rf $path/info/dispositivos_FitaDat.txt 2>/dev/null > /dev/null

# ---------------------------------
# Testa a existencia de scsi Tape
# ---------------------------------
# O pressuposto eh que o equipamento devera 
# ter sido identificado no DMESG
# 
tem_fita=`dmesg | grep "scsi0" | tail -1 | grep tape`
if [ "$tem_fita" = "" ]; then
   rm -rf $path/info/dispositivos_FitaDat.txt  2>/dev/null > /dev/null
   exit 0
fi

what_dev=`dmesg | grep "scsi0" | tail -1 | cut -f4 -d\ `
eh_scsi_tape=`dmesg | grep "scsi0" | tail -1 | cut -f4 -d\ | grep "^st"`
if [ "$eh_scsi_tape" = "" ]; then
   # We got in trouble. So what !
   rm -rf $path/info/dispositivos_FitaDat.txt  2>/dev/null > /dev/null
   exit 0
fi
dev_name=`dmesg | grep "scsi0" | head -1 | cut -f2 -d:` 

echo -e "$what_dev >$dev_name" > $path/info/dispositivos_FitaDat.txt

# ------ End -----  
  
  


