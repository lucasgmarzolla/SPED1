#!/bin/bash
#############################################################################
#
# Copyright (C) 2005 Marcos Nobre - 12/07/2005
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
#
# grava_FitaDat.sh - Grava dados (arquivos) dispostos no diretorio 
#                    ../arquivamento no dispositivo TAPE
# 
# por: Marcos Aurelio Nobre  <marconobre@gmail.com>, em 22/08/2005.
# ultima revisao: 11.09.2005
#                      
#############################################################################


# ---------------------------------------------------------------------------
# Prepara��o inicial
# ---------------------------------------------------------------------------
nomehost=$HOSTNAME
kernel=$(uname -r)
nomeuser=$LOGNAME
sistema=$(uname -o)
DIALOG=dialog
cd_in="f"
cloop="/lib/modules/$kernel/kernel/drivers/block/cloop.*"
PATH="/bin:/sbin:/usr/bin:/usr/sbin"
useconfig="n"

# --------------------------------------------------------------------------------
# -------------------------------- SPED -----------------------------------
# --------------------------------------------------------------------------------
path="/usr/local/jakarta-tomcat-5.5.9/webapps/sped/scripts"
nomeCD="ArqvmtSped"
nomePrep="SpedOperator"
d=`date +%Y%m%d_%H%M`
nomeISO="/tmp/Arquivamento$d.iso"
speed=4
origem="$path/arquivamento/"
# ----------------------------------------------
# se passado um diretorio (local) como argumento
# adota-o como origem do backup
# ----------------------------------------------
if [ "$1" != "" ]; then     
   origem="$1"
fi

# --------------------------------------------------------------------------------
# -------------------------------- SPED -----------------------------------
# --------------------------------------------------------------------------------

cd $path/progs

# -----------------------------------------------------------------
# Desmontar todas as particoes caso o usuario tenha esquecido... ;)
# -----------------------------------------------------------------
while read x mnt x
do
    case "$mnt" in
      /mnt*)
        umount $mnt > /dev/null 2>&1
	;;
    *) ;;
    esac
done < /proc/mounts
umount /mnt/cd* > /dev/null 2>&1

# -----------------------------------------------------------------
# Apaga arquivos temporarios / debug / info
# -----------------------------------------------------------------
rm -rf /tmp/erro.txt > /dev/null 2>&1
rm -rf /tmp/ok.txt > /dev/null 2>&1
rm -rf $path/info/problema_gravacao.txt > /dev/null 2>&1
rm -rf $path/info/arquivamento.txt > /dev/null 2>&1
rm -rf $path/info/identificacao_arquive.txt > /dev/null 2>&1

# -----------------------------------------------------------------
# Pega Resposta
# -----------------------------------------------------------------
if [ -f $path/info/resposta_dispositivo.txt ]; then
   resp=`cat $path/info/resposta_dispositivo.txt | grep "st"`

   #######################################################
   ## Se a resposta nao eh do tipo 'stN' onde N=0,1,2,3...
   ## Entao eh erro
   ## ----------------------------------------------------
   if [ "$resp" = "" ]; then     
      echo -e "Resposta do Usuario (device) Invalida" > $path/info/problema_gravacao.txt
      echo -e "1" > $path/info/arquivamento.txt
      exit 1
   fi

   #################################################
   ## Se nao tem arquivo para gravar  Entao eh erro
   ## ----------------------------------------------
   temarqvmto=`ls -l $origem | grep "^-" | wc -l`
   if [ "$temarqvmto" -eq 0 ]; then
      echo -e "Nao tem arquivo para gravar" > $path/info/problema_gravacao.txt
      echo -e "1" > $path/info/arquivamento.txt
      exit 1
   fi
   
   ftDAT="/dev/n$resp"
   
   rm -rf /tmp/erro.txt > /dev/null 2>&1
   rm -rf /tmp/ok.txt > /dev/null 2>&1
   
   #################################################
   ## Checa se o drive e a midia estao em ordem
   ## ----------------------------------------------
   status=`mt -f $ftDAT status | tail -1`
   erro=`echo -n $status | grep "DR_OPEN"`
   if [ "$erro" != "" ]; then     
      echo -e "Erro: DR_OPEN Porta aberta ou dispositivo sem midia." > $path/info/problema_gravacao.txt
      echo -e "1" > $path/info/arquivamento.txt
      exit 1
   fi
   
   erro=`echo -n $status | grep "WR_PROT"`
   if [ "$erro" != "" ]; then     
      echo -e "Erro: WR_PROT Dispositivo ou Midia nao suporta gravacao." > $path/info/problema_gravacao.txt
      echo -e "1" > $path/info/arquivamento.txt
      exit 1
   fi
      
   #################################################
   ## Posiciona no proximo espaco vago para gravar
   ## ----------------------------------------------
   mt -f $ftDAT rewind > /dev/null 2>&1
   ## O 1o. Arquivamento acontece no FN = 0  !!!!
   fnumber=0
   while mt -f $ftDAT fsf 1 > /dev/null 2>&1 
   do
      sleep 2   
      virgem=`mt -f $ftDAT status | grep "^File"`
      file_number=`echo -n $virgem | cut -f1 -d\, `
      file_number=`echo -n $file_number | cut -f2 -d\= `
      block_number=`echo -n $virgem | cut -f2 -d\, `
      block_number=`echo -n $block_number | cut -f2 -d\= `
      partition=`echo -n $virgem | cut -f3 -d\, `
      partition=`echo -n $partition | cut -f2 -d\= `
      fnumber=`expr $fnumber + 1`
      # Se a fita foi totalmente apagada, o MT nao funciona
      # dai quebra o laco e sai com 1 - teste arbitrario = 1000
      if [ "$fnumber" -gt 1000 ]; then  
         fnumber=1
	 break
      fi
   done
   
#echo -e "------------ $ftDAT ----------"
#echo -e "VIRGEM $virgem"
#echo -e "FILENUMBER $file_number"
#echo -e "FILENUMBER $fnumber"
#echo -e "BLOCKNUMBER $block_number"
#echo -e "PARTITION $partition"
#echo -e "$erro"
#echo -e "$status"
#exit 0
     
   rm -rf /tmp/erro.txt > /dev/null 2>&1
   rm -rf /tmp/ok.txt > /dev/null 2>&1
   rm -rf $path/info/problema_gravacao.txt > /dev/null 2>&1
   rm -rf $path/info/identificacao_arquive.txt > /dev/null 2>&1

   ##########################################################
   ## Queima a midia (em multi-sessao) com conteudo da origem
   ## -------------------------------------------------------
   grava=`tar -cPf $ftDAT $origem 1> /dev/null 2> $path/info/problema_gravacao.txt`
   grava=`ls -s $path/info/problema_gravacao.txt | cut -f1 -d\ `
   grava="--$grava--"
   
   if [ "$grava" != "--0--" ]; then
	echo -e "Problema de gravacao." >> $path/info/problema_gravacao.txt
	echo -e "1" > $path/info/arquivamento.txt
	exit 1
   fi
   rm -rf $path/info/problema_gravacao.txt > /dev/null 2>&1

   ##########################################################
   ## Registra Numero do ARCHIVE para Log
   ## -------------------------------------------------------
   echo -e "$fnumber" > $path/info/identificacao_arquive.txt
   #echo -e "$file_number" > $path/info/identificacao_arquive.txt
   echo -e "0" > $path/info/arquivamento.txt
   
   ######################################################
   ## Estando toda copia correta, APAGA todo conteudo do
   ## sub-diretorio de Arquivamento
   ## ---------------------------------------------------
   rm -rf ${origem}* > /dev/null 2>&1   
else
   echo -e "Sem arquivo: $path/info/resposta_dispositivo.txt" > $path/info/problema_gravacao.txt
   echo -e "1" > $path/info/arquivamento.txt
   exit 1
fi

exit 0

#######################################################
## -------------------- End ---------------------------
#######################################################
