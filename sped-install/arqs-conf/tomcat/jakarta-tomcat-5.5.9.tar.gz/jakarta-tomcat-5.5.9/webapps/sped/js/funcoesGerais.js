/*
 * F�bio Aurelio Maciel Lima - LMR Solu��es em TI
 * Data: 13/12/20007
 */


/*
*  Verifica se existe pelo menos um campos preenchido
*  param1 - Um Array com os ID's dos campos do tipo  TEXT  que v�o ser verificados.
*  verificarCampos() - Aten��o: J� exite uma fun��o com esse nome ! 
*/
function verificarCampos(campos){
	var valido = false;            
	var mensagem = "Todos os campos est�o vazios !"
	var i;
//	alert("Oi, como vai ?")
	try {
		for (i = 0; i < campos.length; i++) {
			campo = document.getElementById(campos[i]);		
		    //alert(campo.name);
			// Simula o trim do JS, nao sei porque mas o trim n�o funciona
			if (!(campo.value.replace(/^\s*/, "").replace(/\s*$/, "")) == ''){				 					
				valido = true;
				break;
			}
		}        	
		if (!valido) {
			alert(mensagem);
		} else {	
	//		alert("Documento OK");
		}
	} catch(err)  {
		  txt="Problemas na valida��o.\n\n";
		  txt+="Descri��o do error : " + err.description + "\n\n";
		  txt+="Click OK para continuar.\n\n";
		  alert(txt);
   }	
   return valido;// esta false s� pra teste, para submeter retorne "valido"
}
 
