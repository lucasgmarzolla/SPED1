// Esse arquivo possui scripts uteis para a verificacao 
// de campos e manipulacao de formularios


/*
 *                        NOTAS SOBRE A BILBLIOTECA:
 *
 * Esta biblioteca faz uso de expressoes regulares em JavaScript para
 * fazer a verificacao de tipos de dados e para outros fins. Expressoes
 * regulares sao uma maneira compacta de descrever linguagens regulares,
 * e constituem um mecanismo muito util para o reconhecimento de padroes
 * (ou patterns) de repeticoes em strings.
 *
 * Mais informacoes sobre expressoes regulares e como utiliza-las no
 * JavaScript podem ser encontradas no tutorial online de JavaScript
 * (secao 'Regular Expressions') disponibilizado pela Netscape no endereco:
 *
 *   http://developer.netscape.com/docs/manuals/js/client/jsguide/index.htm
 */
 
 
/* 
 *              A BIBLIOTECA ESTA DIVIDIDA EM TRES PARTES, SAO ELAS:	 
 *     (a assinatura da funcao e seu comentario completos estao junto a propria.) 
 *
 * 1 - Scripts para verificacao de campos de formularios:
 *
 *      - isFormOK(): 
 *      - isFormPreenchido(): 
 *      - isFormValido(): 
 *      - isCampoPreenchido(): 
 *      - isCampoValido(): 
 *      - isTamanhoExcedido(): verifica o tamanho do texto de um 'textarea' tem tamanho permitido;
 *      - alertarNaoPreenchido(): 
 *      - alertarInvalido(): 
 *      - alertarEstouro(): 
 *      - getNomeCampo(): 
 *		- focarElemento():
 *      - isData(): verifica se uma Data esta num formato escolhido;
 *      - isHora(): verifica se a hora esta no formato 24 horas;      
 *      - validarDataHora()
 *      - verificarCamposPreenchidos(): verifica se os campos obrigatorios estao preenchidos;
 *      - isObrigatorio(): verifica se o campo eh obrigatorio;
 *      - isInteiro(): verifica se eh um inteiro sem sinal;
 *      - isInteiroSinal(): verifica se eh um inteiro com sinal;
 *      - isReal(): verifica se eh um real sem sinal;
 *      - isRealSinal(): verifica se eh um real com sinal;
 *      - isPreenchido(): verifica se o campo especificado em inputid foi preenchido ou selecionado;
 *      - isOpcaoValida(): verifica se a atual opcao selecionada em um select e valida;
 *      - ehDigito(): verifica se Ã© um digito numÃ©rico;
 *      - possuiCasasDecimais(): verifica se possui casas decimais; 
 *      - isTextoValido(): verifica se Ã© um texto valido;
 *		- isEmailValido(): verifica se o email digitado � um email v�lido.
 *		- isCPFValido(): verifica se um n�mero do cpf digitado � v�lido.
 *	- confirmaExclusao(nomeObjeto): Exibe ao usu�rio uma mensagem "tem certeza que deseja excluir <nomeObjeto>?" e retorna um booleano
 *
 *
 * 2 - Scripts para manipulacao de elementos de formularios:
 *
 *      - moverConteudoSelects(): move o conteudo selecionado de uma caixa de selecao para outra;
 *		- concatenarOpcoesSelect(): concatena os options de um select;
 *		- getIndiceOpcao():busca o indice de uma opcao dentro de uma caixa de selecao dado seu valor;
 *		- removerOpcoes(): remove os opcoes selecionados em uma caixa de selecao;
 *		- removerOptions(): remove todas as opcoes de uma caixa de selecao;
 *		- writeEspaco(): coloca caracteres de espaco simples;
 *		- alertOpcoesSelecionadas(): abre uma janela de advertencia que exibe itens selecionados; 
 *		- eliminarEspacos(): elimina os espacos do conteudo de um campo;
 *		- trim(): elimina os espacos em branco (tabulacao, quebra de linha, espaco) do comeco e do fim;
 *		- addObr(): registra um elemento como obrigatorio;
 *		- toMaiuscula(): escreve o texto passado em letras maiusculas;
 *		- trocaSeparador(): troca o separador de um numero passado com casas decimais;
 *		- colocaCasasDecimais(): retorna o numero recebido com casas decimais;
 *		- formatarNumero(): formata o numero com quantas casas decimais quizer;
 *		- somar(): soma dois numeros em que o separador Ã© a virgula;
 *		- filtrarTexto(): elimina os caracteres desejados de uma string;
 *		- formatarMoeda(): formata um número qualquer no padrão de moeda (485,22) com 2 casas decimais.
 *		- getNumCasasDecimais(): retorna o numero de casas decimais de uma string;
 *		- formatarData(): gerencia a formatacao das datas conforme o usuario digita;
 *      - formatarDataHora(): gerencia a formatacao de data e hora conforme o usuario digita;
 *		- formatarCPF(): formata o numero do CPF;
 *		- exibeCPF(): retorna uma string formatada de uma string nao formatada; 	
 * 		- focar(): coloca o foco sobre um objeto fornecido;
 * 		- atualizarParametroURL(): substitui o valor de um parametro em uma URL
 * 		- formatarPercentual()
 * 		- isJavaEnabled()
 * 		- formatarCartaoCredito()
 * 		- formatarCGC()
 * 		- formatarTelefone()
 *		- formatarData(): formata a data dinamicamente e verifica se esta no formato "dd/mm/aaaa"
 *		- formatarCEP(): formata o cep dinamicamente no formato nnnnn-nnn.
 
 *
 * 3 - Scripts uteis no processo de teste e remocao de erros (debugging):
 *
 *		- mostrarArray();
 *		- mostrarArray2D();
 */	
 
 
//definicao das expressoes regulares usadas nesta biblioteca
//var _reInt = /^\d+$/;                //numeros inteiros positivos (sem sinal)
var _reInteiro = /^(\+|-)?\d+$/;       //numeros inteiros
var _reInteiroSinal = /^(\+|-)\d+$/;   //numeros inteiros com sinal
var _reReal = /^(\+|-)?\d*\.\d+$/;     //numeros reais
var _reRealSinal = /^(\+|-)\d*\.\d+$/; //numeros reais com sinal
var _reEspacos = /\s*/;                //espacos em branco (inclui tabulacao, espaço, quebra de linha)
var _reEspacosIniciais = /^\s*/;       //espacos em branco no inicio de string
var _reEspacosFinais = /\s*$/;         //espacos em branco no final de string
var _reEmailValido = /^([a-zA-Z0-9_\-])+(\.([a-zA-Z0-9_\-])+)*@((\[(((([0-1])?([0-9])?[0-9])|(2[0-4][0-9])|(2[0-5][0-5])))\.(((([0-1])?([0-9])?[0-9])|(2[0-4][0-9])|(2[0-5][0-5])))\.(((([0-1])?([0-9])?[0-9])|(2[0-4][0-9])|(2[0-5][0-5])))\.(((([0-1])?([0-9])?[0-9])|(2[0-4][0-9])|(2[0-5][0-5]))\]))|((([a-zA-Z0-9])+(([\-])+([a-zA-Z0-9])+)*\.)+([a-zA-Z])+(([\-])+([a-zA-Z0-9])+)*))$/;
var _reTextoValido = "&nbsp;abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.?,!:;@#$_&()+-=/*[]{}Ã§Ã‡Ã� Ã€Ã¢Ã‚ÃªÃ� Ã´Ã�?Ã¡Ã�?Ã©Ã‰Ã­Ã�?Ã³Ã“ÃºÃšÃ£ÃƒÃ¼ÃœÃµÃ•Ã¶Ã– \n\r\t";
var _reNomeArquivo = "&nbsp;abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,!;@#$_&()+-=[]{}";

//definicao de mensagens de erro genÃ©ricas
var _msgPreencherObr = "Favor preencher os seguintes campos obrigatórios: ";

// para uso da funcao isCampoPreenchido().
// deixa a funcao mais eficiente evitando criticar todos os
// 'radio' de um grupo se um jah foi verificado.
var ultimoRadioVerificado;
var isGrupoRadioPreenchido;


            //---------------------------------------------------
            // Scripts para verificacao de campos de formularios
            //---------------------------------------------------


//-------------------------isFormOK()----------------------------------------
/**
 * Verifica se um formulario esta com todos os seus campos obrigatorios
 * preenchidos e se o preenchimento de cada um esta de acordo com o tipo
 * de dado esperado.
 *
 * Os elementos de formulario suportados sao:
 * - hidden
 * - password
 * - radio
 * - select
 * - text
 * - textarea
 * - file
 *
 * Para cada 'input' dos tipos acima, passam a ser considerados os atributos:
 * - 'obrigatorio'
 * 		. 'true' = o campo deve estar preenchido.
 *		. um campo so eh considerado preenchido se tiver algum caracter diferente
 * 		  de espacos, tabulacoes e quebras de linha.
 * - 'validar'
 * 		. 'inteiro' = o valor do campo deve ser um numero inteiro.
 * 		. 'numero' = o valor do campo deve ser um numero real.
 * 		. 'data' = o campo deve estar preenchido com uma data no formato dd/mm/aaaa.
 * 		. 'texto' = o campo deve ter um texto valido.
 * - 'nome_logico'
 *		. nome do campo mostrado em um alerta caso ele esteja invalido.
 *		. se nao estiver presente e o campo estiver invalido, mostra o nome fisico
 * - 'valor_invalido'
 *		. apenas para 'select', diz o valor que a opcao selecionada
 * 		  nao pode ter.
 * - 'tamanho_maximo'
 *		. apenas para 'textarea', diz o tamanho maximo que o texto pode ter (contando
 *		  espacos, tabulacoes e quebras de linha).
 *
 * @author Ricardo Fonseca e Campos - Mirante
 * @since 30/06/2003
 * @version 01/07/2003
 */
function isFormOK(objForm, naoAlertar) {
	if (!isFormPreenchido(objForm, naoAlertar)) {
		return false;
	}
	if (!isFormValido(objForm, naoAlertar)) {
		return false;
	}
	return true;
}

//-------------------------isFormPreenchido()----------------------------------------
/**
 *
 */
function isFormPreenchido(objForm, naoAlertar) {
	// anula a ultima verificacao de marcacao de um grupo de botoes 'radio', se for o caso.
	ultimoRadioVerificado = null;
	isGrupoRadioPreenchido = false;
	
	for (var i = 0, tam = objForm.elements.length; i < tam; i++) {
		var obj = objForm.elements[i];

		if (!isCampoPreenchido(obj)) {
			alertarNaoPreenchido(obj, naoAlertar);
			focarElemento(obj);
			return false;
		}
	}
	return true;
}

//-------------------------isFormValido()----------------------------------------
/**
 *
 */
function isFormValido(objForm, naoAlertar) {
	for (var i = 0, tam = objForm.elements.length; i < tam; i++) {
		var obj = objForm.elements[i];

		if (!isCampoValido(obj)) {
			alertarInvalido(obj, naoAlertar);
			focarElemento(obj);
			return false;
		}
		
		// apenas 'textarea': detecta mais texto que o permitido
		if (isTamanhoExcedido(obj)) {
			alertarEstouro(obj, naoAlertar);
			focarElemento(obj);
			return false;
		}
	}
	return true;
}

//-------------------------isCampoPreenchido()----------------------------------------
/**
 * Verifica se um campo de um formulario esta preenchido.
 *
 * Os elementos de formulario suportados sao:
 * - hidden
 * - password
 * - radio
 * - text
 * - textarea
 * - select
 * - file
 *
 * Um 'select' do tipo "combo-box" ou "menu drop-down" sempre estah preenchido
 * jah que ele eh mostrado na tela com alguma opcao selecionada.
 * Jah um 'select' do tipo "list-box" nao tem inicialmente uma opcao selecionada.
 * Por isso, o atributo 'obrigatorio' serve para o 'select'.
 *
 * Para cada 'input' dos tipos acima, passam a ser considerados os atributos:
 * - 'obrigatorio'
 * 		. 'true' = o campo deve estar preenchido.
 *		. um campo so eh considerado preenchido se tiver algum caracter diferente
 * 		  de espaco, tabulacao e quebra de linha.
 * - 'nome_logico'
 *		. nome do campo mostrado em um alerta caso ele nao esteja preenchido; caso
 *        esteja ausente, mostra o nome fisico no alerta.
 *
 * @author Ricardo Fonseca e Campos - Mirante
 * @since 01/07/2003
 * @version 01/07/2003
 */
function isCampoPreenchido(objCampo) {
	if (objCampo.obrigatorio == true || objCampo.obrigatorio == 'true') {

		if ((objCampo.type == 'hidden')
				|| (objCampo.type == 'text')
				|| (objCampo.type == 'textarea')
				|| (objCampo.type == 'password')) {

			// nao preenchido
			if ((objCampo.value == null) || (trim(objCampo.value) == '')) {
				return false;
			}
		}

		// nao verificar espacos em branco na senha
		//if (objCampo.type == 'password') {

			// nao preenchido (senha pode ser em branco ou soh espacos)
		//	if (objCampo.value == null) {
		//		return false;
		//	}
		//}

		if (objCampo.type == 'radio') {

			// se jah percorreu algum dos 'radio' do grupo desse.
			// a cada verificacao de preenchimento do grupo 'radio', esse valor
			// deve ser anulado para que o ultimo resultado obtido nao seja retornado
			if ((ultimoRadioVerificado != null)
					&& (ultimoRadioVerificado.name == objCampo.name)) {

				return isGrupoRadioPreenchido;
			}

			// guarda o primeiro dos 'radio' do grupo para evitar
			// que todos os outros do mesmo grupo sejam verificados
			ultimoRadioVerificado = objCampo;

			formRadio = objCampo.form;
			numRadio = eval('formRadio.' + objCampo.name + '.length');

			// verifica se algum dos outros 'radio' de mesmo nome está preenchido
			for (var j = 0; j < numRadio; j++) {
				var objRadio = eval('formRadio.' + objCampo.name + '[j]');

				if (objRadio.type == 'radio' && objRadio.checked) {
					// eh certo que ao menos um dos 'radio' do grupo estah marcado
					return (isGrupoRadioPreenchido = true);
				}
			}

			return (isGrupoRadioPreenchido = false);
		}

		// so faz sentido para list-box (size > 1 || multiple)
		if ((objCampo.type == 'select-one') || (objCampo.type == 'select-multiple')) {

			// nenhuma opcao selecionada
			if (objCampo.selectedIndex == -1) {
				return false;
			}
		}
		
		// verifica se j� foi escolhido algum arquivo
		if (objCampo.type == 'file') {
		
			if ((objCampo.value == null) || (trim(objCampo.value) == '')) {
				return false;
			}
		}
	}

	// se o campo nao for suportado ou nao for obrigatorio
	return true;
}

//-------------------------isCampoValido()----------------------------------------
/**
 * Verifica se um campo de um formulario esta preenchido de forma correta.
 *
 * Os elementos de formulario suportados sao:
 * - hidden
 * - select
 * - text
 * - textarea
 *
 * Para cada 'input' dos tipos acima, passam a ser considerados os atributos:
 * - 'validar'
 * 		. 'inteiro' = o valor do campo deve ser um numero inteiro.
 * 		. 'numero' = o valor do campo deve ser um numero real.
 * 		. 'data' = o campo deve estar preenchido com uma data no formato dd/mm/aaaa.
 * 		. 'texto' = o campo deve ter um texto valido (expressao regular).
 *                  se o campo pode ter qualquer valor alem de letras validas,
 *                  nao validar e apenas verificar o preenchimento.
 *		. 'nome_arquivo' = nomes de arquivos v�lidos (windows).
 *      . 'email' = o valor do campo deve ser um email v�lido.
 *		. 'cpf' = o valor do campo deve ser um cpf v�lido.
 *      . desnecessario para um 'textarea' que aceita qualquer valor e apenas tem
 *        a restricao do tamanho (ver atributo 'tamanho_maximo').
 *      . desnecessario para um 'select' (ver atributo 'valor_invalido').
 * - 'nome_logico'
 *		. nome do campo mostrado em um alerta caso ele esteja invalido.
 *		. se nao estiver presente e o campo estiver invalido, mostra o nome fisico
 * - 'valor_invalido'
 *      . validado sem a necessidade do atributo 'validar'
 *		. apenas para 'select', diz o valor que a opcao selecionada nao pode ter.
 * - 'tamanho_maximo'
 *      . validado sem a necessidade do atributo 'validar'
 *		. apenas para 'textarea', diz o tamanho maximo que o texto pode ter (contando
 *		  espacos, tabulacoes e quebras de linha).
 *
 * @author Ricardo Fonseca e Campos - Mirante
 * @since 30/06/2003
 * @version 01/07/2003
 */
function isCampoValido(objCampo) {
	// verifica se a opcao selecionada do 'select' tem valor valido;
	// nao continua o processamento do metodo
	if (((objCampo.type == 'select-one') || (objCampo.type == 'select-multiple'))
			&& (objCampo.selectedIndex != -1)
			&& (objCampo.valor_invalido != null)) {

		posicao = objCampo.selectedIndex;

		// selecionou opcao invalida
		if (objCampo.options[posicao].value == objCampo.valor_invalido) {
			return false;
		}

		return true;
	}
	
	if(objCampo.name == 'CEP'){
		formatarCEP(objCampo);
	}

	// pediu validacao
	if ((objCampo.validar != null) && (trim(objCampo.validar) != '')) {

		// soh faz validacao de dado para 'hidden', 'text' e 'textarea'
		if ((objCampo.type == 'hidden')
				|| (objCampo.type == 'text')
				|| (objCampo.type == 'textarea')) {

			valor = objCampo.value;
			tipo = objCampo.validar;

			if ((tipo == 'inteiro') && !isInteiro(valor)) {
				return false;
			}

			if ((tipo == 'numero') && !isReal(valor)) {
				return false;
			}

			if ((tipo == 'data') && (!isData(valor, "dd/mm/aaaa"))) {
				return false;
			}

			if ((tipo == 'texto') && !isTextoValido(valor)) {
				return false;
			}
			
			if ((tipo == 'nome_arquivo') && !isNomeArquivoValido(valor)) {
				return false;
			}

			if ((tipo == 'email') && !isEmailValido(valor)) {
				return false;
			}

			if ((tipo == 'cpf') && !isCPFValido(valor)){
				return false;
			}
		}
	}

	return true;
}

//-------------------------isTamanhoExcedido()----------------------------------------
/**
 * Verifica se o texto digitado em um 'textarea' tem tamanho permitido.
 *
 * Para um 'textarea', eh considerado o atributo:
 * - 'tamanho_maximo'
 *      . validado sem a necessidade do atributo 'validar'
 *		. diz o tamanho maximo que o texto pode ter contando espacos,
 *        tabulacoes e quebras de linha.
 */
function isTamanhoExcedido(objCampo) {
	if ((objCampo.type == 'textarea')
			&& (objCampo.value != null)
			&& (objCampo.tamanho_maximo != null)
			&& isInteiro(objCampo.tamanho_maximo)
			&& (objCampo.value.length > objCampo.tamanho_maximo))
		return true;
}

//-------------------------alertarNaoPreenchido()----------------------------------------
/**
 *
 */
function alertarNaoPreenchido(objCampo, naoAlertar) {
	if (!(naoAlertar == true) || !(naoAlertar == 'true')) {

		nomeCampo = getNomeCampo(objCampo);

		if (objCampo.type == 'hidden') {
			alert('Favor preencher "' + nomeCampo + '" (campo escondido).');

		} else if ((objCampo.type == 'select-one')
					|| (objCampo.type == 'select-multiple')
					|| (objCampo.type == 'radio')) {
			alert('Favor escolher alguma op��o em "' + nomeCampo + '".');

		} else if ((objCampo.type == 'text')
					|| (objCampo.type == 'textarea')
					|| (objCampo.type == 'password')) {
			alert('Favor preencher "' + nomeCampo + '".');

		} else if (objCampo.type == 'file') {
			alert('Favor escolher um arquivo em "' + nomeCampo + '".');
		}
	}
}

//-------------------------alertarInvalido()----------------------------------------
/**
 *
 */
function alertarInvalido(objCampo, naoAlertar) {
	if (!(naoAlertar == true) || !(naoAlertar == 'true')) {

		nomeCampo = getNomeCampo(objCampo);

		if (objCampo.type == 'hidden') {
			alert('Desculpe, mas o valor de "' + nomeCampo +
				'" (campo escondido) � inv�lido.');

		} else if ((objCampo.type == 'select-one')
					|| (objCampo.type == 'select-multiple')) {
			alert('Desculpe, mas a op��o selecionada em "' + nomeCampo +
				'" � inv�lida.');

		} else if ((objCampo.type == 'text') || (objCampo.type == 'textarea')) {
			alert('Desculpe, mas o valor de "' + nomeCampo +
				'" � inv�lido.');
		}
	}
}

//-------------------------alertarEstouro()----------------------------------------
/**
 *
 */
function alertarEstouro(objCampo, naoAlertar) {
	if (!(naoAlertar == true) || !(naoAlertar == 'true')) {
		nomeCampo = getNomeCampo(objCampo);

		alert('Desculpe, mas o texto de "' + nomeCampo +
			'" excedeu o tamanho m�ximo (' + objCampo.tamanho_maximo + ').');
	}
}

//-------------------------getNomeCampo()----------------------------------------
/**
 *
 */
function getNomeCampo(objCampo) {
	return (objCampo.nome_logico == null) ? objCampo.name : objCampo.nome_logico;
}

//-------------------------focarElemento()----------------------------------------
/**
 *
 */
function focarElemento(objCampo) {
	if ((objCampo.type != null) && (objCampo.type != 'hidden')) {
		objCampo.focus();
	}
}



// -------------------verificarCamposPreenchidos()-----------------------------
/*
 * A funcao abaixo verifica se os campos obrigatorios estao preenchidos e, se
 * estiverem, submite o formulario. Para que seja verificado por esta funcao,
 * todo campo de preenchimento obrigatorio deve ter o nome precedido pelo
 * prefixo 'obr_', por exemplo, 'obr_meu_campo'.
 *
 * parametros:
 *    form -> formulario que devera ter os campos obrigatorios verificados
 */
function verificarCamposPreenchidos( objForm ) {
  var nome = null;

  for( i = 0; i < form.length; i++ ) {
    nome = form.elements[i].name;
    if ( isObrigatorio( nome ) ) {
      //campo Ã© obrigatorio, verificar se foi preenchido
      if ( eliminarEspacos( form.elements[i].value ) == "" ) {
        alert( "Favor preencher todos os campos obrigatorios." );
        return;
      }
    }
  }

  //o form so Ã© submetido abaixo se todos os campos obrigatorios foram preenchidos
  form.submit();
}


// --------------------------isObrigatorio()----------------------------------------
/*
 * A funcao abaixo verifica se um campo Ã© obrigatorio. Para determinar se o campo
 * Ã© obrigatorio, procura-se pelo prefixo 'obr_' no nome do campo.
 *
 * parametro:
 *    objInput -> input a ser determinado se eh obrigatorio
 *
 * retorna: 'true' -> se o campo for obrigatorio
 *          'false' -> caso contrario
 */
function isObrigatorio(objInput) {
  if ( nomeCampo.substring( 0, 4 ) == "obr_" ) {
    return true;
  } else {
    return false;
  }
}


// --------------------------------isInteiro()-------------------------------------------
/*
 * Esta funcao verifica se o argumento eh um numero inteiro (com ou sem sinal).
 *
 * Parametros:
 *   numStr -> string a ser validada como um inteiro positivo
 *
 * Retorno:
 *   retorna 'true' caso o argumento seja inteiro e 'false' caso contrario.
 */
function isInteiro( numStr ) {
  return _reInteiro.test( numStr );
}


// ----------------------------- isInteiroSinal()------------------------------------
/*
 * Esta funcao verifica se o argumento eh um numero inteiro com sinal.
 *
 * Parametros:
 *   numStr -> string a ser validada como um inteiro com sinal
 *
 * Retorno:
 *   retorna 'true' caso o argumento seja inteiro e 'false' caso contrario.
 */
function isInteiroSinal( numStr ) {
  return _reInteiroSinal.test( numStr );
}


// -----------------------------isReal()-----------------------------------------
/*
 * Esta funcao verifica se o argumento Ã© um numero real positivo (sem sinal).
 *
 * Parametros:
 *   numStr -> string a ser validada como um numero real positivo
 *
 * Retorno:
 *   retorna 'true' caso o argumento seja real e 'false' caso contrario.
 */
function isReal( numStr ) {
  return _reReal.test( numStr );
}


// -----------------------------isRealSinal()------------------------------------
/*
 * Esta funcao verifica se o argumento eh um numero real com sinal.
 *
 * Parametros:
 *   numStr -> string a ser validada como um numero real com sinal
 *
 * Retorno:
 *   retorna 'true' caso o argumento seja inteiro e 'false' caso contrario.
 */
function isRealSinal( numStr ) {
  return _reRealSinal.test( numStr );
}

// -------------------------isPreenchido()-----------------------------
/*
 * Verifica se um campo text ou textarea estão preenchidos.
 *
 * Um alerta de erro eh mostrado caso o nome do campo seja passado.
 *
 * Parametros:
 *  inputid --> objeto input que sera verificado
 *  nomeCampoAlerta (opcional) --> nome do campo que será mostrado no alerta
 *  semTrim (opcional) --> se 'true', a funcao considera os espacos no inicio
 *                         e fim do campo como preenchimento
 */
function isPreenchido(objInput, nomeCampoAlerta, semTrim) {
    var str = objInput.value;
    
    if (semTrim == true) {
    	str = str.trim();
    }

    if (str.length == 0) {
    	if (nomeCampoAlerta != null) {
    		window.alert('Favor preencher o campo ' + nomeCampoAlerta);
    	}
        return false;
    }
    
    return true;
}


// -------------------------isOpcaoValida()-----------------------------
/*
 * Verifica se a opção selecionada em um combo-box ou list-box (campo tipo 'select')
 * é diferente da opcao invalida.
 *
 * Parametros:
 *  objSelect --> objeto 'select'
 *  valorOpcaoInvalida --> valor da opcao invalida
 *  nomeCampoAlerta (opcional) --> nome do campo que será mostrado no alerta
 */
function isOpcaoValida(objSelect, valorOpcaoInvalida, nomeCampoAlerta) {
    if (objSelect.value == valorOpcaoInvalida) {
    	if (nomeCampoAlerta != null) {
    		window.alert('Favor escolher uma opção válida para ' + nomeCampoAlerta);
    	}
    	return false;
    }

    return true;
}


// -----------------------------------isTextoValido()-------------------------------------
/**
 * A expressao regular utilizada ainda EH MUITO RESTRITA!!
 */
function isTextoValido(texto) {
    for (var i=0; i<texto.length; i++) {
        letra = "" + texto.substring(i, i+1);
        if (_reTextoValido.indexOf(letra) == "-1") {
            return false;
        }
    }
    return true;
}

// -----------------------------------isNomeArquivoValido()-------------------------------------
/**
 * 
 */
function isNomeArquivoValido(texto) {
    for (var i=0; i<texto.length; i++) {
        letra = "" + texto.substring(i, i+1);
        if (_reNomeArquivo.indexOf(letra) == "-1") {
            return false;
        }
    }
    return true;
}

// -----------------------------------isEmailValido()-------------------------------------
/**
 * A expressao regular utilizada valida, inclusive, emails com endere�o IP!!
 */
function isEmailValido(email) {

    return _reEmailValido.test(email);	
}


// -----------------------------------isCPFValido()-------------------------------------
/**
 * O valor de entrada dessa fun��o deve estar no formato: xxx.xxx.xxx-xx, onde x deve ser
 * um d�gito  [0-9]. � sugerido o uso da fun��o formatarCPF para o campo de que ir� passar
 * o valor para essa fun��o.
 * Essa fun��o realiza todos os c�lculos para verficar se um dado n�mero de 11 digitos �
 * um n�mero de cpf v�lido de acordo com as regras para um n�mero de cpf.
 * Retirado da internet. Autor desconhecido.
 */
function isCPFValido(s1){
    var i;
    var s ="";

    if (s1 == "") {
        return true;
    }

    for (i = 0; i < 14 ; i++) {
        if (s1.charAt(i) != "." && s1.charAt(i) != "-")
           s += s1.charAt(i);
    }

    var c = s.substr(0,9);
    var dv = s.substr(9,2);
    var d1 = 0;
    for (i = 0; i < 9; i++) {
        d1 += c.charAt(i)*(10-i);
    }

    if (d1 == 0){
        return false;
    }

    d1 = 11 - (d1 % 11);

    if (d1 > 9) d1 = 0;
    if (dv.charAt(0) != d1) {
	    return false;
    }

    d1 *= 2;

    for (i = 0; i < 9; i++) {
	    d1 += c.charAt(i)*(11-i);
    }

    d1 = 11 - (d1 % 11);

    if (d1 > 9) d1 = 0;
    if (dv.charAt(1) != d1) {
	    return false;
    }
    return true;
}



// -----------------------------------confirmaExclusao()-------------------------------------
/**
 * 	Exibe ao usu�rio uma mensagem "tem certeza que deseja excluir <nomeObjeto>?" e retorna um booleano
 */
function confirmaExclusao(nomeObjeto){
	return confirm("Tem certeza que deseja excluir " + nomeObjeto + "?");
}




           //-------------------------------------------------------------
           // Scripts para manipulacao de elementos de formularios
           //-------------------------------------------------------------


// -------------------------moverConteudoSelects()-------------------------------------
/*
 * A funcao abaixo move o conteudo selecionado de uma caixa de selecao (multipla
 * ou simples) para outra caixa de selecao.
 *
 * parametros:
 *    selectOrigem -> caixa de selecao (select) de origem
 *    selectDestino -> caixa de selecao de destino
 */
function moverConteudoSelects(selectOrigem, selectDestino ) {
  var indiceDestino = selectDestino.length;
  var optionOrigem = null;

  var i = null;
  for ( i = 0; i < selectOrigem.length; i++ ) {
    optionOrigem = selectOrigem.options[i];

    if ( optionOrigem.selected ) {
      // verificar se a opcao sendo movida nao existe no select de destino
      if ( getIndiceOpcao( selectDestino, optionOrigem.value ) == -1 ) {
        // a opcao nao existe no select de destino e pode ser movida
        selectDestino.options[indiceDestino] = new Option();
        selectDestino.options[indiceDestino].text = optionOrigem.text;
        selectDestino.options[indiceDestino].value = optionOrigem.value;
        indiceDestino++;

        // remover a opcao do select de origem
        optionOrigem = null;
        selectOrigem.options[i] = null;

        // o contador i deve ser decrementado, pois a opcao de indice i
        // foi removida.
        i--;
      } else {
        // a opcao ja existe no select de destino
        alert( "a opcao '" + optionOrigem.text + "' ja existe no destino." );
      }
    }
  }
}


// ------------------------------concatenarOpcoesSelect()-------------------------------------

/**
 * Concatena os valores (ou qualquer outro atributo) das opcoes selecionadas
 * de um combo-box ou list-box (campo 'select').
 *
 * @param objSelect -> objeto 'select'
 * @param delim -> delimitador
 * @param propriedade (opcional) -> atributo do 'option' que sera concatenado. Se
 *                                  nao informado, o valor ('value') eh concatenado.
 *
 */
function concatenarOpcoesSelect(objSelect, delim, propriedade) {
  if (objSelect == null || objSelect.length == 0) {
  	return '';
  }
  
  var n = objSelect.length;
  var res = "", temp;

  // default  
  if (propriedade == null) {
  	propriedade = 'value';
  }

  for (i = 0; i < n; i++) {
    option = objSelect.options[i];

    if (option.selected) {
      eval('temp = option.' + propriedade);

      if (temp != null) {
      	res += temp + delim;
      }
    }
  }
  
  // retira o ultimo delimitador (desnecessario) inserido
  return res.substring(0, res.length - 1);
}


// --------------------------------getIndiceOpcao()--------------------------------------
/*
 * A funcao abaixo busca o indice de uma opcao dentro de uma caixa de selecao
 * dado seu valor.
 *
 * parametros:
 *    objSelect -> objeto select no qual a opcao deve ser buscada.
 *    valorOption -> valor da opcao a ser buscada no select
 *
 * retorna: indice da opcao caso esta foi encontrada, ou -1 caso contrario.
 */
function getIndiceOpcao(objSelect, valorOption) {
  var i = null;

  for ( i = 0; i < objSelect.length; i++ ) {
    if (objSelect.options[i].value == valorOption) {
      return i;
    }
  }

  return -1;
}



// -----------------------------removerOpcoes()-------------------------------
/*
 * A funcao abaixo remove as opcoes, selecionadas ou nao, de uma caixa de selecao.
 *
 * parametros:
 *    objSelect -> o objeto select do qual a opcoes selecionadas devem
 *                    ser removidas.
 *    apenasSelecionados (opcional) -> se apenas os selecionados serao excluidos
 */
function removerOpcoes(objSelect, apenasSelecionados) {
  for (var i = 0; i < objSelect.length; i++ ) {

    if (apenasSelecionados && !objSelect.options[i].selected) {
      continue;
    }

    objSelect.options[i] = null;
    i--;
  }
}


// --------------------------------writeEspaco()-----------------------------------------
/*
 * Escreve caracteres de espaco HTML ('&nbsp') no local do documento HTML de onde
 * a funcao foi chamada.
 *
 * parametros:
 *    num -> numero de espacos
 */
function writeEspaco(num) {
  for(var i = 0; i < numSpaces; i++ ) {
    document.write( "&nbsp;" );
  }
}



// ---------------------------alertOpcoesSelecionadas()------------------------------------
/*
 * A funcao abaixo abre uma janela de advertencia - chamando o mÃ©todo 'alert()'
 * do JavaScript - que exibe os valores dos itens selecionados em uma caixa de
 * selecao.
 *
 * parametros:
 *    selectObject -> o objeto select do qual as opcoes selecionadas devem ser
 *                    exibidas.
 */
function alertOpcoesSelecionadas( selectObject ) {
  var mensagem = "valores das opcoes selecionadas: ";
  var optionAtual = null;

  var i = null;

  for ( i = 0; i < selectObject.length; i++ ) {
    optionAtual = selectObject.options[i];

    if ( optionAtual.selected ) {
      mensagem += '\n\t' + optionAtual.text + " = '" + optionAtual.value + "'";
    }
  }

  alert( mensagem );
}


// -----------------------------trimStr()------------------------------------

/*
 * A funcao abaixo utiliza a expressao regular que representa caracteres
 * de espaco (espacos simples, tabulacoes, etc.), para apara-los de uma
 * string. Somente sao aparados os espacos em branco no inicio e no final
 * da string (espacos intermediarios nao sao removidos).
 *
 * Parametros:
 *   str -> string a ser aparada.
 *
 * Retorno:
 *   retorna a string aparada.
 */
function trim(valor) {
  return valor.toString().replace(_reEspacosIniciais, '').replace(_reEspacosFinais, '');
}


// --------------------------toMaiuscula()-----------------------------------

/*
 * A funcao abaixo escreve um texto todo em maiusculas
 */
function toMaiuscula(txt) {
  document.write(txt.toUpperCase());
}


// -----------------------------formatarNumero()---------------------------------------------

/*
 * Formata um numero com quantas casas decimais se quiser, mesmo que ele
 * ja possua casas decimais.
 *
 * Se o numero ja possui casas decimais, o separador atual pode ser substituido,
 * se for especificado, e se o numero de casas decimais pedido por menor que o atual,
 * entao a funcao efetua arredondamento.
 *
 * Pode ser usado para gerenciar o campo enquanto o usuario o preenche.
 *
 * Parametros:
 *   numero -> numero a ser processado
 *   numCasas -> numero de casas decimais desejadas
 *   separador -> separador que sera usado no numero retornado
 *   separadorErrado (opcional) -> separador utilizado que deve ser trocado pelo correto
 */
function formatarNumero(numero, numCasas, separador, separadorErrado) {
  if (numero == null || numero == '') {
  	return '';
  }
  
  numero = numero.toString().replace(separadorErrado, separador);

  posicao = numero.indexOf(separador);

  if (posicao == -1) {
    numero += separador;
    for (i = 1; i <= numCasas; i++) {
      numero += "0";
    }
    return numero;
  }

  tamanho = numero.length;

  for (i = posicao+1; i<= posicao+numCasas; i++) {

    if (i >= tamanho) { // significa q nao existem mais digitos no numero
      numero += "0";

    // codigo para arredondamento
    } else if ((i == posicao+numCasas) && (i < tamanho-1)) {
      j = i+1;

      if (numero.charAt(j) >= '5') { // condicao para o arredondamento
        dig = eval(numero.charAt(i)); // digito a ser arredondado

        if (dig == 9) { // condicao para arredondar o digito antecessor tambem
          if (numero.charAt(i-1) == separador) {  // se o numero desejado tiver 2 casas decimais, o comportamento sera diferenciado.
            dig2 = eval(numero.charAt(i-2)) + 1;
            numero = numero.substring(0, i-2) + dig2.toString() + numero.substring(i-1, i);

          } else {
            dig2 = eval(numero.charAt(i-1)) + 1;
            numero = numero.substring(0, i-1) + dig2.toString() + numero.substring(i, i);
          }
          dig = 0; //nesse caso o digito passa de 9 para 0

        } else {
          dig++;
        }
        numero = numero.substring(0, i) + dig.toString();
      }
    }
  }

  //numero = numero.toString().substring(0, eval(aux + numCasas + 1));
  return numero.substring(0, i);
}


// -----------------------------somar()--------------------------------------------------

/*
 * Este funcao soma dois numeros em que o separador eh virgula
 */
function somar(num1, num2) {
  num1 = num1.toString().replace(',', '.');
  num2 = num2.toString().replace(',', '.');
  aux = eval(num1 + " + " + num2);
  return aux.replace('.', ',');
}


// -----------------------------filtrarTexto()-------------------------------------------

/*
 * Esta funcao recebe uma string e elimina todos os caracteres iguais a carac
 * nela contida
 */
function filtrarTexto(strng, carac) {
  while (strng.indexOf(carac) != -1) {
    index = strng.indexOf(carac);
    if (index == "0") {
      strng = strng.substring(1,strng.length);

    } else if (index == strng.length) {
      strng = strng.substring(0, strng.length - 1);

    } else {
      strng = strng.substring(0, index) + strng.substring(eval(index + 1), strng.length);
    }
  }
  return strng;
}


// ------------------------------formatarMoeda()------------------------------------

/*
 * Gerencia a posicao da virgula conforme o usuario entra com digitos de um valor monetario
 *
 * ex: f(123) = 1,23  , onde f(123) eh o resultado desta
 *                          funcao aplicada ao valor 123.
 *
 * Supondo agora q o usuario entra com "4", temos:
 *     f(1,234) = 12,34
 *
 * O separador de digitos padrao eh a virgula!
 *
 * Parametros:
 *   str -> numero a ser formatado
 *   numCasas -> numero de casas decimais desejadas
 *
 * @TODO implementar a funcao incrementaSeparador
 */
function formatarMoeda(numero, separador) {
  if (numero == null || numero == '') {
  }
  
  numero = numero.toString().trim();
  
  if (separador == null) {
  	separador = ",";
  }
  
  indexSeparador = numero.indexOf(separador);

  if (indexSeparador == -1) {
    if ((numero.charAt(0) == " ") && (numero.length == 1)){
        return "";
    }
    if (str.length == 1) {
        return separador + " " + numero;
    } 
    return numero;
  }

  if (numero.indexOf(separador, indexSeparador + 1) > indexSeparador) {
    return numero.substring(0,numero.length - 1);
  } 
  if (getNumCasasDecimais(numero) == "1") {
    return incrementaSeparador(numero, "-1"); // separador vai para tras
  }

  numero = incrementaSeparador(numero, "1"); // separador vai para frente

  if (numero.charAt(0) == " "){
    return numero.substring(1, numero.length);
  }
  return numero;
}


// --------------------------getNumCasasDecimais()-----------------------------------

/*
 * Esta funcao que retorna o numero de casas decimais de 'str'.
 * Atencao: separador padrao Ã© a virgula!
 */
function getNumCasasDecimais( str ) {
  separador = ","; //separador padrao!
  indexSeparador = str.indexOf(separador);
  if ((indexSeparador == -1) || (indexSeparador == str.length-1)) {
    return "0"
  }
  else return str.length - indexSeparador - 1;
}



// -------------------------------formatarCPF()----------------------------------------

/*
 * Funcao mascara de CPF. Ela pode gerenciar a digitacao do CPF pelo usuario dinamicamente.
 * Autor: Diego Diehl
 * Inspirada na funcao do BB
 * Atualiza��es: Daniel Corr�a de Azevedo
 *
 * a chamada deve ser feita da seguinte forma:
 * Onkeyup=formatarCPF(seucampo);
 *
 * Parametros:
 *   campo -> nome do campo
 */
function formatarCPF( campo ) {
  if ( campo == '' || document.form.elements.length == 0 ) {
    return false;
  }
  
  var num = parseInt(campo);

  if ( document.form[campo] ) {
    vr = document.form[campo].value;
    vr = vr.replace( /[^0-9]/, "" );
	vr = vr.replace("." , "");
	vr = vr.replace("." , "");
	vr = vr.replace("-" , "");
    tam = vr.length;

    if ( tam <= 2 ){
      document.form[campo].value = vr;
    }
    if ( (tam > 2) && (tam <= 5) ){
      document.form[campo].value = vr.substr( 0, tam - 2 ) + '-' + vr.substr( tam - 2, tam );
    }	
    if ( (tam > 5) && (tam <= 8) ){
      document.form[campo].value = vr.substr( 0, tam - 5 ) + '.' + vr.substr( tam - 5, 3 ) + '-' + vr.substr( tam - 2, tam );
    }
    if ( (tam > 8) && (tam <= 11) ){
      document.form[campo].value = vr.substr( 0, tam - 8 ) + '.' + vr.substr( tam - 8, 3 ) + '.' + vr.substr( tam - 5, 3 ) + '-' + vr.substr( tam - 2, tam );
    }
  }
}


// ---------------------------------exibeCPF()----------------------------------------
/*
 * Retorna uma string formatada de CPF, a partir de uma string
 * nao formatada.
 * Autor: Edmundo
 * Baseada na mesma logica da funcao formatarCPF.
 * A diferenca eh que exibeCPF eh util na apresentacao de campos de CPF,
 * enquando formatarCPF eh util no momento da edicao.
 *
 * Entrada: String data
 * Saida: String data
 *
 * separadores usados: "." e "-"
 * formato padrao: "999.999.999-99"
 */
function exibeCPF( str ) {
  res = "";

  tam = str.length;
  if ( tam <= 2 ){
    res = str;
  }
  if ( (tam > 2) && (tam <= 5) ){
    res = str.substr( 0, tam - 2 ) + '-' + str.substr( tam - 2, tam );
  }
  if ( (tam >= 6) && (tam <= 8) ){
    res = str.substr( 0, tam - 5 ) + '.' + str.substr( tam - 5, 3 ) + '-' + str.substr( tam - 2, tam );
  }
  if ( (tam >= 9) && (tam <= 11) ){
    res = str.substr( 0, tam - 8 ) + '.' + str.substr( tam - 8, 3 ) + '.' + str.substr( tam - 5, 3 ) + '-' + str.substr( tam - 2, tam );
  }
  if ( (tam >= 12) && (tam <= 14) ){
    res = str.substr( 0, tam - 11 ) + '.' + str.substr( tam - 11, 3 ) + '.' + str.substr( tam - 8, 3 ) + '.' + str.substr( tam - 5, 3 ) + '-' + str.substr( tam - 2, tam );
  }
  if ( (tam >= 15) && (tam <= 17) ){
    res = str.substr( 0, tam - 14 ) + '.' + str.substr( tam - 14, 3 ) + '.' + str.substr( tam - 11, 3 ) + '.' + str.substr( tam - 8, 3 ) + '.' + str.substr( tam - 5, 3 ) + '-' + str.substr( tam - 2, tam );
  }

  return res;
}

// --------------------------------focar()---------------------------------------------

/*
 * Coloca o foco no objeto cujo nome ou posicao no formulario eh fornecida.
 * muito util quando o nome do objeto contem hifens ('-') e etc...
 * chamada onload=focar("campo").
 */

function focar( campofoco ) {
  if ( campofoco == '' || document.form.elements.length == 0 ) {
    return false;
  }

  var num = parseInt(campofoco);

  if ( num || num == 0 ) {
    if ( document.form[num] ) {
      document.form[num].focus();
    }
  } else{
    if ( document.form[campofoco] ) {
      document.form[campofoco].focus();
    }
  }
}

// ------------------------------atualizarParametroURL()----------------------------------

/**
 * Substitui o valor de um parametro em uma URL.
 *
 * @param url a URL onde esta o parametro
 * @param nomeParam o nome do parametro cujo valor sera substituido
 * @param novoValor o novo valor do parametro
 * @return a URL em que o parametro teve seu valor substituido
 *
 * @author Ricardo Fonseca e Campos - Mirante
 * @version 21/05/2002
 */
function atualizarParametroURL(url, nomeParam, novoValor) {
    alert(2);
    alert('passou1: ' + 'url.indexOf("' + nomeParam + '", 0)');
    var i = eval('url.indexOf("'+nomeParam+'", 0)');
    alert('passou1.5');
    if (url == null || nomeParam == null || i == -1) {
        return url;
    }
    alert('passou2');

    var pos1 = url.indexOf(nomeParam);
    var novaUrl = url.substring(0, pos1) + nomeParam + '=' + novoValor;

    var pos2 = url.indexOf('&', pos1 + 1);
    if (pos2 != -1) {
        novaUrl += url.substring(pos2);
    }

    return novaUrl;
}

      //-------------------------------------------------------------------
      // Scripts uteis no processo de teste e remocao de erros (debugging)
      //-------------------------------------------------------------------


// -------------------------mostrarArray()-------------------------------------
function mostrarArray( nomeArray, arrayRef ) {
  var mensagem = "conteudo do array '" + nomeArray + "':\n";
  
  var i = null;
  for ( i = 0; i < arrayRef.length; i++ ) {
    mensagem += "   " + nomeArray + "[" + i + "] = " + arrayRef[i];
    if ( arrayRef[i] == null ) {
      mensagem += " (null)";
    } else {
      mensagem += " (not null)";
    }
    mensagem += "\n";
  }
  
  alert( mensagem );
}

// ------------------------mostrarArray2D()------------------------------------
function mostrarArray2D( nomeArray, arrayRef ) {
  var mensagem = "conteudo do array '" + nomeArray + "':\n";
  
  var i = null;
  var j = null;
  for ( i = 0; i < arrayRef.length; i++ ) {
    for ( j = 0; j < arrayRef[i].length; j++ ) {
      mensagem += "   " + nomeArray + "[" + i + "][" + j + "] = " + arrayRef[i] + "\n";
    }
  }
  
  alert( mensagem );
}

function formatarPercentual(campo,tammax,teclapres) {
	var tecla = teclapres.keyCode;
	vr = document.form[campo].value;
	vr = vr.replace( "/", "" );
	vr = vr.replace( "/", "" );
	vr = vr.replace( ",", "" );
	vr = vr.replace( ".", "" );
	vr = vr.replace( ".", "" );
	vr = vr.replace( ".", "" );
	vr = vr.replace( ".", "" );
	tam = vr.length;

	if (tam < tammax && tecla != 8){ tam = vr.length + 1 ; }

	if (tecla == 8 ){	tam = tam - 1 ; }
		
	if ( tecla == 8 || tecla >= 48 && tecla <= 57 || tecla >= 96 && tecla <= 105 ){
		if ( tam <= 3 ){ 
	 		document.form[campo].value = vr ; }
	 	if ( (tam > 3) && (tam <= 6) ){
	 		document.form[campo].value = vr.substr( 0, tam - 3 ) + ',' + vr.substr( tam - 3, tam ) ; }
	}		
	
}


function isJavaEnabled() {
	if (navigator.javaEnabled()) {
		document.form.javas.value="sim"
	}
}

function formatarCartaoCredito(campo, teclapres) {
    var tammax = 16;
	var tecla = teclapres.keyCode;
	vr = document.form[campo].value;

	if ( tecla == 8 || (tecla >= 48 && tecla <= 57) || (tecla >= 96 && tecla <= 105) )
	{
		vr = vr.replace( "/", "" );
		vr = vr.replace( "/", "" );
		vr = vr.replace( ",", "" );
		vr = vr.replace( ".", "" );
		vr = vr.replace( ".", "" );
		vr = vr.replace( ".", "" );
		vr = vr.replace( ".", "" );
		vr = vr.replace( "-", "" );
		vr = vr.replace( "-", "" );
		vr = vr.replace( "-", "" );
		vr = vr.replace( "-", "" );
		vr = vr.replace( "-", "" );
		tam = vr.length;

		if (tam < tammax && tecla != 8)
		   {tam = vr.length + 1 ; }

		if (tecla == 8 ) {tam = tam - 1 ; }

		if ( tam < 5 )
		   { document.form[campo].value = vr ; }
	 	if ( ( tam >  4 ) && ( tam < 9 ) )
		   { document.form[campo].value = vr.substr( 0, 4 ) + '.' + vr.substr( 4, tam-4 ) ; }
	 	if ( ( tam >  8 ) && ( tam < 13 ) )
		   { document.form[campo].value = vr.substr( 0, 4 ) + '.' + vr.substr( 4, 4 ) + '.' + vr.substr( 8, tam-4 ) ; }
	 	if ( tam > 12 )
		   { document.form[campo].value = vr.substr( 0, 4 ) + '.' + vr.substr( 4, 4 ) + '.' + vr.substr( 8, 4 ) + '.' + vr.substr( 12, tam-4 ); }
	}	
}

function formatarCGC(campo,tammax,teclapres) {
	var tecla = teclapres.keyCode;
	vr = document.form[campo].value;
	vr = vr.replace( "/", "" );
	vr = vr.replace( "/", "" );
	vr = vr.replace( "/", "" );
	vr = vr.replace( ",", "" );
	vr = vr.replace( ".", "" );
	vr = vr.replace( ".", "" );
	vr = vr.replace( ".", "" );
	vr = vr.replace( ".", "" );
	vr = vr.replace( ".", "" );
	vr = vr.replace( ".", "" );
	vr = vr.replace( ".", "" );
	vr = vr.replace( "-", "" );
	vr = vr.replace( "-", "" );
	vr = vr.replace( "-", "" );
	vr = vr.replace( "-", "" );
	vr = vr.replace( "-", "" );
	tam = vr.length;

	if (tam < tammax && tecla != 8){ tam = vr.length + 1 ; }

	if (tecla == 8 ){	tam = tam - 1 ; }
		
	if ( tecla == 8 || tecla >= 48 && tecla <= 57 || tecla >= 96 && tecla <= 105 ){
		if ( tam <= 2 ){ 
	 		document.form[campo].value = vr ; }
	 	if ( (tam > 2) && (tam <= 6) ){
	 		document.form[campo].value = vr.substr( 0, tam - 2 ) + '-' + vr.substr( tam - 2, tam ) ; }
	 	if ( (tam >= 7) && (tam <= 9) ){
	 		document.form[campo].value = vr.substr( 0, tam - 6 ) + '/' + vr.substr( tam - 6, 4 ) + '-' + vr.substr( tam - 2, tam ) ; }
	 	if ( (tam >= 10) && (tam <= 12) ){
	 		document.form[campo].value = vr.substr( 0, tam - 9 ) + '.' + vr.substr( tam - 9, 3 ) + '/' + vr.substr( tam - 6, 4 ) + '-' + vr.substr( tam - 2, tam ) ; }
	 	if ( (tam >= 13) && (tam <= 14) ){
	 		document.form[campo].value = vr.substr( 0, tam - 12 ) + '.' + vr.substr( tam - 12, 3 ) + '.' + vr.substr( tam - 9, 3 ) + '/' + vr.substr( tam - 6, 4 ) + '-' + vr.substr( tam - 2, tam ) ; }
	 	if ( (tam >= 15) && (tam <= 17) ){
	 		document.form[campo].value = vr.substr( 0, tam - 14 ) + '.' + vr.substr( tam - 14, 3 ) + '.' + vr.substr( tam - 11, 3 ) + '.' + vr.substr( tam - 8, 3 ) + '.' + vr.substr( tam - 5, 3 ) + '-' + vr.substr( tam - 2, tam ) ;}
	}		
}

function formatarTelefone(campo,tammax,teclapres) {
	var tecla = teclapres.keyCode;
	vr = document.form[campo].value;
	vr = vr.replace( "/", "" );
	vr = vr.replace( "/", "" );
	vr = vr.replace( ",", "" );
	vr = vr.replace( ".", "" );
	vr = vr.replace( ".", "" );
	vr = vr.replace( ".", "" );
	vr = vr.replace( ".", "" );
	vr = vr.replace( "-", "" );
	vr = vr.replace( "-", "" );
	vr = vr.replace( "-", "" );
	vr = vr.replace( "-", "" );
	vr = vr.replace( "-", "" );
	tam = vr.length;

	if (tam < tammax && tecla != 8){ tam = vr.length + 1 ; }

	if (tecla == 8 ){	tam = tam - 1 ; }
		
	if ( tecla == 8 || tecla >= 48 && tecla <= 57 || tecla >= 96 && tecla <= 105 ){
		if ( tam <= 2 ){ 
	 		document.form[campo].value = vr ; }
	 	if ( (tam > 4) ){
	 		document.form[campo].value = vr.substr( 0, tam - 4 ) + '-' + vr.substr( tam - 4, tam ) ; }
	}		
}

/********************************************************************** 
Fun��o de valida��o de campos do tipo Data 

Objetivos : 
    - Aceitar somente datas do tipo : dd/mm/aaaa 

Par�metros : 
    objeto        -> Nome do campo de formul�rio (Usar this) 

Exemplo : 
    OnChange    isData(this); 
/**********************************************************************/ 
function isData(valor) {

    var DataArray    = valor.split("/");
    var Flaging = true; 


    if (DataArray.length != 3) 
        Flaging=false; 
    else 
        { 
            if (DataArray.length==3) 
            { 
                var dia = DataArray[0], mes = DataArray[1], ano = DataArray[2]; 

                if (((Flaging) && (ano<1000) || ano.length>4)) 
                    Flaging=false; 
                 
                if (Flaging) 
                { 
                    verifica_mes = new Date(mes+"/"+dia+"/"+ano); 
                    if (verifica_mes.getMonth() != (mes - 1)) 
                        Flaging=false; 
                } 
            } 
            else 
                Flaging=false; 
        } 
return Flaging; 
} 

/********************************************************************** 
Fun��o de formata��o de campos do tipo Data 

Objetivos : 
    - Mascarar a entrada de dados no formato : dd/mm/aaaa 

Par�metros : 
    objeto        -> Nome do campo de formul�rio (Usar this) 

Exemplo : 
    OnKeyPress    formatarData(this); 
	OnKeyUP       formatarData(this); 

Requirido : 
    Fun��o isData 
/**********************************************************************/ 
function formatarData(obj, event) 
{ 
   if(obj.value.length < 11){
		//alert(obj.value);
		var valorData = obj.value;
	    var ultCaracter = valorData.substring(valorData.length - 1, valorData.length);


		separador = '/'; 
		conjunto1 = 2;
		conjunto2 = 5;
		if (valorData.length == conjunto1 && event.keyCode !=8){
			 valorData = valorData + separador;
			
		}
		if (valorData.length == conjunto2 && event.keyCode !=8){

				valorData = valorData + separador;
		}
		obj.value = valorData; 
   }
}

/********************************************************************** 
Fun��o de formata��o de campos do tipo CEP 

Objetivos : 
    - Mascarar a entrada de dados no formato : nnnnn-nnn

Par�metros : 
    objeto        -> Nome do campo de formul�rio (Usar this) 
 
Exemplo : 
    OnKeyPress    formatarCEP(this); 

/**********************************************************************/ 
function formatarCEP(objeto)
	{
	campo = eval (objeto);
	formato = "CEP";
	if (formato=='CEP')
		{
		caracteres = '01234567890';
		separacoes = 1;
		separacao1 = '-';
		conjuntos = 2;
		conjunto1 = 5;
		conjunto2 = 3;
		if ((caracteres.search(String.fromCharCode (window.event.keyCode))!=-1) && campo.value.length < 
		(conjunto1 + conjunto2 + 1))
			{
			if (campo.value.length == conjunto1) 
			   campo.value = campo.value + separacao1;
			}
		else 
			event.returnValue = false;
		}
	}
	
/********************************************************************** 
Fun��o que retira os caracteres que excedem ao tamanho m�ximo de um text-area

Objetivos : 
    - Retirar os caracteres al�m do m�ximo permitido a medida que s�o digitados

Par�metros : 
    objeto           -> Nome do campo de formul�rio (Usar this) 
    nroCaracteres    -> N�mero de caracteres permitidos 
 
Exemplo : 
    onchange      contaCaracteres(this, 100);
    OnKeyUp       contaCaracteres(this, 100);

/**********************************************************************/ 
function contaCaracteres(objeto, nroCaracteres) {
    campo = eval (objeto);
	nroCaracteres = nroCaracteres --;
	intCaracteres = nroCaracteres - campo.value.length;
	if (intCaracteres > 0) {
		return true;
	} else {
		campo.value = campo.value.substr(0,nroCaracteres);
		return false;
	}
}

/********************************************************************** 
Fun��o que valida formato e valor v�lido para hora.

Objetivos : 
    - Validar hora de 24 horas

Par�metros : 
    StringHora           -> Valor da hora a ser validada

/**********************************************************************/ 
function isHora(strHora){ 
              hrs = (strHora.substring(0,2)); 
              minut = (strHora.substring(3,5)); 
              
              situacao = ""; 
              // verifica data e hora 
              if ((hrs < 00 ) || (hrs > 23) || ( minut < 00) ||( minut > 59)){ 
                  situacao = "falsa"; 
              } 
              if (situacao == "falsa") { 
          			return false 
              } 
			  return true;
          } 


/********************************************************************** 
Fun��o que ajuda a preecher o formato data hora

Objetivos : 
    - Formatar data hora(Ex: 22/12/2005 20:45)

Par�metros : 
    objeto           -> Nome do campo de formul�rio (Usar this) 
 
Exemplo : 
	onkeypress    mascaraFormatoDataHora(this);
	onkeyup       mascaraFormatoDataHora(this);

/**********************************************************************/ 
function mascaraFormatoDataHora(obj){
	var data, hora;
	if(obj.value.length < 11){
		//alert(obj.value);
		var valorData = obj.value;
	    separador = '/'; 
		conjunto1 = 2;
		conjunto2 = 5;
		if (valorData.length == conjunto1){
			 valorData = valorData + separador;
		}
		if (valorData.length == conjunto2){
			valorData = valorData + separador;
		}
		obj.value = valorData; 
		
	}else{
		if (obj.value.length > 7){
			if(obj.value.substr(10,1)!=" "){
			obj.value = obj.value.substr(0,10) + " " + obj.value.substr(10,1);
			}
			resto = obj.value.substr(11,(obj.value.length-1));
			if(resto.length == 2){
				obj.value = obj.value + ':'; 
			}			
		}
	}
	
}
/********************************************************************** 
Fun��o que validar formato data hora

Objetivos : 
    - Validar data hora(Ex: 22/12/2005 20:45)

Par�metros : 
    objeto           -> Nome do campo de formul�rio (Usar this) 
	messagem         -> deve ser passada, caso seja passada vazia ser� considerada a mensagem padr�o
 
Exemplo : 
	onblur   validarDataHora(this, 'Aqui vai minha mensagem de alerta');
	
/**********************************************************************/ 
function validarDataHora(obj, menssagem){
	var strObj = obj.value;
	var msg ='';
	if(trim(menssagem)!=''){
		msg= menssagem;
	}else{
		msg = "Formato data hora inv�lido. Exemplo v�lido: '12/12/2005 14:00'\nDigite a data e hora v�lidas.";
    }
		erro = false;
	if (strObj.length < 16)	{
		alert(msg);	
		obj.value = '';
	}else{
		strData = strObj.substr(0,10);
		strHora = strObj.substr(11,5);
		if(!isData(strData)){
		  erro = true;
		}
		
		if(!isHora(strHora)){
			erro = true;
		}	
		if(erro){
			alert(msg);
			obj.value = "";
		}
		

	}
}
/********************************************************************** 
Fun��o que validar formato data

Objetivos : 
    - validar data hora(Ex: 22/12/2005)

Par�metros : 
    objeto           -> Nome do campo de formul�rio (Usar this) 
	messagem         -> deve ser passada, caso seja passada vazia ser� considerada a mensagem padr�o
 
Exemplo : 
	onblur   validarData(this, 'Aqui vai minha mensagem de alerta');
	
/**********************************************************************/ 
function validarData(obj, menssagem){
	var strObj = obj.value;
	var msg ='';
	if(trim(menssagem)!=''){
		msg= menssagem;
	}else{
		msg = "Data inv�lida. Exemplo v�lido: '12/12/2005'";
    }
	if(!isData(strObj)){
      alert(msg);
	  obj.value='';
	  return false;
	}
	return true;
}
	


