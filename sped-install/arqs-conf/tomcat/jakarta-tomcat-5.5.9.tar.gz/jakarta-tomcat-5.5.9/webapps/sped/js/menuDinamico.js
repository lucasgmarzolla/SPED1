/*
 * FUN��ES JAVASCRIPT UTILIZADAS PARA IMPLEMENTAR O MENU DIN�MICO
 *
 * autor:   Denis Oliveira
 * desde:   23/10/2003
 * vers�o:  17/11/2003
 */

//VARI�VEIS GLOBAIS
var objItemAtivo; //guarda uma refer�ncia para o �ltimo item clicado no menu
var nomeItemAtivo; // guarda o nome para o ultimo item clicado no menu

/*
 * Expande um item do menu, mostrando seus filhos.
 */
function expandirItem( obj ) {
  //obter o <div> com os filhos do <div> atual
  var divFilhos = getNextSiblingByTagName( obj, "div" );

  //trocar a imagem do "+" pelo "-"
  trocarImagemExpander( obj );

  //exibir o <div> (atualizar propriedade CSS 'display')
  divFilhos.style.display = 'block';
}

/*
 * Contrai um item do menu, escondendo seus filhos.
 */
function contrairItem( obj ) {
  //obter o <div> com os filhos do <div> atual
  var divFilhos = getNextSiblingByTagName( obj, "div" );

  //trocar a imagem do "-" pelo "+"
  trocarImagemExpander( obj );

  //esconder o <div> (atualizar propriedade CSS 'display')
  divFilhos.style.display = 'none';
}

/*
 * Atualiza um item do menu, expandindo ou contraindo-o de acordo com seu
 * estado atual (Se o item estiver expandido, deve contra�do, e vice-versa).
 */
function atualizarItem( obj ) {
  //verifica pelo atributo 'isExpanded'
  if ( obj.isExpanded == undefined ) {
    obj.isExpanded = false;
  }

  if ( obj.isExpanded ) {
    contrairItem( obj );
    obj.isExpanded = false;
  } else {
    expandirItem( obj );
    obj.isExpanded = true;
  }
}

/*
 * Troca a imagem do "+" pelo "-" quando um item que tem filhos � expandido, e
 * troca de volta quando o item � contra�do.
 */
function trocarImagemExpander( obj ) {
  var expanderImg = getNextChildByTagName( obj, "img" );
  while ( expanderImg != null ) {
    if ( expanderImg.id == "itemExpander" ) {
      break;
    }
    expanderImg = getNextSiblingByTagName( expanderImg, "img" );
  }

  var imgUrl = expanderImg.src;
  var fileName = imgUrl.substring( imgUrl.lastIndexOf( "/" ) + 1 );
  var newFileName = null;
  switch ( fileName ) {
    case "plus.gif": newFileName = "minus.gif"; break;
    case "plusbottom.gif": newFileName = "minusbottom.gif"; break;
    case "minus.gif": newFileName = "plus.gif"; break;
    case "minusbottom.gif": newFileName = "plusbottom.gif"; break;
  }

  if ( newFileName != null ) {
    imgUrl = imgUrl.substring( 0, imgUrl.lastIndexOf( "/" ) + 1 ) + newFileName;
    expanderImg.src = imgUrl;
  } else {
    window.alert( "N�o foi poss�vel fazer a troca de imagens do folder!" );
  }
}

/*
 * Dado um elemento html, procura o primeiro elemento irm�o cujo nome
 * da tag � passado como segundo argumento.
 */
function getNextSiblingByTagName( elemento, nomeTagIrmao ) {
  var irmao = elemento;
  while ( ( irmao = irmao.nextSibling ) != null ) {
    if ( irmao.nodeType == 1 && irmao.tagName.toLowerCase() == nomeTagIrmao.toLowerCase() ) {
      break;
    }
  }

  return irmao;
}

/*
 * Dado um elemento html, procura o primeiro elemento filho cujo nome
 * da tag � passado como segundo argumento.
 */
function getNextChildByTagName( elemento, nomeTagFilho ) {
  var filho = null;
  for ( var i = 0; i < elemento.childNodes.length; i++ ) {
    if ( elemento.childNodes[i].tagName.toLowerCase() == nomeTagFilho.toLowerCase() ) {
      filho = elemento.childNodes[i];
      break;
    }
  }

  return filho;
}

/*
 * Contrasta um item do menu, em resposta a um evento "MouseOver", por exemplo.
 */
function contrastarItem( obj, cssText ) {
  if ( arguments.length == 2 ) {
    obj.style.cssText = cssText;
    obj.cssContraste = cssText;
  } else if ( arguments.length == 1 ) {
    obj.style.cssText = obj.cssContraste;
  }
}

/*
 * Tira o contraste de um item do menu.
 */
function descontrastarItem( obj ) {
  //descontrastar o item do menu somente se ele n�o estiver ativo (se n�o foi o
  //�ltimo a ser clicado)
  if ( obj != objItemAtivo ) {
    obj.style.cssText = '';
  }
}

/*
 * Ativa um item do menu, guardando o id do item na propriedade
 * 'document.idItemAtivo'.
 */
function ativarItem( obj ) {
  //guardar o item ativado anteriormente
  var objAnterior = objItemAtivo

  //guardar o novo item ativo
  objItemAtivo = obj;
  // guardar o nome do item ativo
  document.nomeItemAtivo = objItemAtivo.innerHTML;

  /*
   * definir uma propriedade chamada 'idItemAtivo' no objeto 'document',
   * de maneira que a refer�ncia 'document.idItemAtivo' guarde sempre o
   * id do item ativo.
   */
  document.idItemAtivo = objItemAtivo.id;

  //verificar se havia um item ativado e desativ�-lo
  if ( objAnterior != undefined && objAnterior != null ) {
    descontrastarItem( objAnterior );
  }

  //contrastar o novo item
  contrastarItem( objItemAtivo );
}

/*
 * Obt�m o 'id' do item atualmente ativo no menu. Se n�o houver item ativo,
 * o valor devolvido � nulo (null).
 */
function getIdItemAtivo() {
  if ( objItemAtivo != undefined && objItemAtivo != null ) {
    return objItemAtivo.id;
  }

  return null
}

//DEBUG
function debugObject( obj ) {
  var propNames = new Array();

  for ( var p in obj ) {
    propNames[propNames.length] = p;
  }

  propNames.sort();

  for ( var i = 0; i < propNames.length; i++ ) {
    top.conteud.document.write( propNames[i] + "='" + obj[propNames[i]] + "' (" + typeof( obj[propNames[i]] ) + ")<br />" );
  }
}