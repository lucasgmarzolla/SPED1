/**
 * Detecta o navegador do cliente. Mas diferencia apenas Mozilla de Firefox de IE.
 * Outros navegadores, como Opera e Safari, ser�o tratados como Mozilla
 * j� que n�o foi pedido suporte para navegadores al�m dos 3 primeiros.
 */
function getBrowser() {
	if (navigator.userAgent.toLowerCase().indexOf("firefox") != -1)
		return 'firefox'
	
	if (navigator.userAgent.toLowerCase().indexOf("msie") != -1)
		return 'ie'
	
	return 'mozilla'
}

/**
 * O funcionamento do Firefox � semelhante ao do Mozilla. Por isso, os dois
 * s�o tratados igualmente aqui.
 */

function getTextoAjuda() {

	var brauzer = getBrowser();
	var texto;
	var nomeBotaoF5 = 'Atualizar';
	
	texto = '- Recomenda��es de Configura��o da P�gina -\n\n';

	if ((brauzer == 'firefox') || (brauzer == 'mozilla')) {

		if (navigator.language.toLowerCase() == 'pt-br') {
			// browser em portugu�s
			texto += '1. V� no menu "Arquivo" / "Configurar P�gina...";\n';
			texto += '2. Clique na aba "Margens";\n';
			texto += '3. Na se��o "Cabe�alho e Rodap�", deixe todos os campos vazios;\n';
			texto += '4. Na se��o "Margens", defina a margem superior para\n';
			texto += '0,3cm ou 3,0mm, dependendo da escala usada.\n';
			texto += '\n --> Para imprimir, v� no menu "Arquivo" / "Imprimir...".\n';

		} else {
			// browser em ingl�s
			texto += '1. V� no menu "File" / "Page Setup...";\n';
			texto += '2. Clique na aba "Margins & Header/Footer";\n';
			texto += '3. Na se��o "Header/Footer", deixe todos os campos vazios;\n';
			texto += '4. Na se��o "Margins", defina a margem superior para\n';
			texto += '0.3cm ou 3.0mm, dependendo da escala usada.\n';
			texto += '\n --> Para imprimir, v� no menu "File" / "Print...".\n';
			
			nomeBotaoF5 = 'Reload';
		}

	} else if (brauzer == 'ie') {
	
		if (navigator.userLanguage.toLowerCase() == 'pt-br') {
			// browser em portugu�s
			texto += '1. V� no menu "Arquivo" / "Configurar P�gina...";\n';
			texto += '2. Na se��o "Cabe�alhos e Rodap�s", deixe todos os campos vazios;\n';
			texto += '3. Na se��o "Margens", defina a margem superior para\n';
			texto += '\ \ \ \ 1cm ou 10mm, dependendo da escala usada.\n';
			texto += '\n --> Para imprimir, v� no menu "Arquivo" / "Imprimir...".\n';
			
		} else {
			// browser em ingl�s
			texto += '1. V� no menu "File" / "Page Setup...";\n';
			texto += '2. Na se��o "Headers and Footers", deixe todos os campos vazios;\n';
			texto += '3. Na se��o "Margins", defina a margem superior para\n';
			texto += '\ \ \ \ 1cm ou 10mm, dependendo da escala usada.\n';
			texto += '\n --> Para imprimir, v� no menu "File" / "Print...".\n';
			
			nomeBotaoF5 = 'Refresh';
		}
	}
	
	texto += '\n(para rever essa mensagem, clique no bot�o "' + nomeBotaoF5 + '" do navegador)';
	
	return texto;
}


function ajudaImpressao() {

/*	

	'+a se��o do manual e configurar seu navegador para impress�o, ou clique em "Cancelar"'
	'+ se esse navegador j� est� configurado para impress�o.'
*/
var name=confirm("Para que o documento seja impresso segundo as instru��es gerais 'IG 10-42'"
                 +" � necess�rio configurar a impress�o nesse navegador. Clique em OK para abrir"
                 +" a se��o do manual e configurar seu navegador para impress�o, ou clique em 'Cancelar'"
				 +" se esse navegador j� est� configurado para impress�o.");
if (name==true)
{
//	  var win = window.open('/sped_manual/Manual_do_Usuario/','replace');
//	  window.frameElement("elaborandoConfigTipoBrowser.htm");
//	  win.document.write("elaborando/elaborandoConfigTipoBrowser.htm")
//	  win.document.location = "/sped_manual/Manual_do_Usuario/elaborando/elaborandoConfigTipoBrowser.htm";
//      win.frames[2].document.location = "/sped_manual/Manual_do_Usuario/elaborando/elaborandoConfigTipoBrowser.htm";
	  
	window.print();
      
}
else
{
	window.print();
}	
}
