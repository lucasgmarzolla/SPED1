// Adaptado de 'http://www.soxiam.com/Code/MakeTableColumnsSortableWithJavascript'

addEvent(window, "load", ordenaveis_init);

var INDICE_COLUNA_ORDENACAO;

function ordenaveis_init() {
    // Acha todas as tabelas com a classe ordenavel e as faz ordenaveis
    if (!document.getElementsByTagName) return;
    tbls = document.getElementsByTagName("table");
    for (ti=0;ti<tbls.length;ti++) {
        estaTbl = tbls[ti];
        // As tabelas s�o da classe ordenavel e possuem um id
        if (((' '+estaTbl.className+' ').indexOf("ordenavel") != -1) && (estaTbl.id)) {
            ts_facaOrdenavel(estaTbl);
        }
    }
}

function ts_facaOrdenavel(table) {
    if (table.rows && table.rows.length > 0) {
        var primeiraLinha = table.rows[0];
    }
    if (!primeiraLinha) return;

    // Temos uma primeira linha: fa�a com que o conte�do das c�lulas sejam links para ordena��o
    for (var i=0;i<primeiraLinha.cells.length;i++) {
        var celula = primeiraLinha.cells[i];
        var txt = ts_pegarTextoInterno(celula);
        // verifica se n�o estamos pegando uma c�lula vazia
        if (txt.match(/[^\s\n]/))
        	celula.innerHTML = '<a href="#" class="celulaOrdenavel" align="center" onclick="ts_reordenarTabela(this);return false;">'+txt+'<span class="setaOrdenacao"></span></a>';
    }
}

function ts_pegarTextoInterno(elemento) {
	if (typeof elemento == "string") return elemento;
	if (typeof elemento == "undefined") { return elemento };
	if (elemento.innerText) return elemento.innerText;
	var str = "";

	var cs = elemento.childNodes;
	var l = cs.length;
	for (var i = 0; i < l; i++) {
		switch (cs[i].nodeType) {
			case 1: // Elemento (DOM)
				str += ts_pegarTextoInterno(cs[i]);
				break;
			case 3:	// Texto (DOM)
				str += cs[i].nodeValue;
				break;
		}
	}
	return str;
}

function ts_reordenarTabela(lnk, contexto) {
    // trabalha a seta de ordena��o
    var span;
    for (var ci=0;ci<lnk.childNodes.length;ci++) {
        if (lnk.childNodes[ci].tagName && lnk.childNodes[ci].tagName.toLowerCase() == 'span') span = lnk.childNodes[ci];
    }
    var textoSpan = ts_pegarTextoInterno(span);
    var td = lnk.parentNode;
    var coluna = td.cellIndex;
    var tabela = pegarPai(td,'TABLE');

    INDICE_COLUNA_ORDENACAO = coluna;
    
    var primeiraLinha = new Array();
    var novasLinhas = new Array();
    primeiraLinha = tabela.rows[0];
    for (j=1;j<tabela.rows.length;j++) { novasLinhas[j-1] = tabela.rows[j]; }
    
    // Lida com o tipo da coluna
    if (tabela.rows.length <= 1) return;
    var item = ts_pegarTextoInterno(tabela.rows[0].cells[coluna]);
    if (item.match(/((d|D)ata)/)){
    	// a data pode ter diferentes formatos
    	funcao_ordenacao = parser_ordena_data(novasLinhas);
    }else if (item.match(/((p|P)rotocolo)/)){
    	funcao_ordenacao = ts_ordena_numerico;
    }else if (item.match(/((p|P)atente)/)){
    	var contexto = document.getElementById("contexto").value;    	
    	if (contexto == "fab"){    		
    		funcao_ordenacao = ordenaFAB;
    	}else{
    		funcao_ordenacao = ts_ordena_patente;
    	}
    }else{
    	funcao_ordenacao = ts_ordena_sem_caixa;
    }
    
    novasLinhas.sort(funcao_ordenacao);

    if (span.getAttribute("direcaoOrdenacao") == 'baixo') {
        SETA = '&nbsp;&nbsp;&uarr;';
        novasLinhas.reverse();
        span.setAttribute('direcaoOrdenacao','cima');
    } else {
        SETA = '&nbsp;&nbsp;&darr;';        
        //novasLinhas.reverse();//altera��o        
        span.setAttribute('direcaoOrdenacao','baixo');
    }

	// N�o entendi pq o sortbottom...
    // We appendChild rows that already exist to the tbody, so it moves them rather than creating new ones
    // don't do sortbottom rows
    for (i=0;i<novasLinhas.length;i++) { if (!novasLinhas[i].className || (novasLinhas[i].className && (novasLinhas[i].className.indexOf('sortbottom') == -1))) tabela.tBodies[0].appendChild(novasLinhas[i]);}
    // do sortbottom rows only
    for (i=0;i<novasLinhas.length;i++) { if (novasLinhas[i].className && (novasLinhas[i].className.indexOf('sortbottom') != -1)) tabela.tBodies[0].appendChild(novasLinhas[i]);}

    // Apaga qualquer outra seta que possa estar aparecendo
    var todosSpans = document.getElementsByTagName("span");
    for (var ci=0;ci<todosSpans.length;ci++) {
        if (todosSpans[ci].className == 'setaOrdenacao') {
            if (pegarPai(todosSpans[ci],"table") == pegarPai(lnk,"table")) {
                todosSpans[ci].innerHTML = '';
            }
        }
    }

    span.innerHTML = SETA;
}

function pegarPai(elemento, pTagName) {
	if (elemento == null) return null;
	else if (elemento.nodeType == 1 && elemento.tagName.toLowerCase() == pTagName.toLowerCase())
		return elemento;
	else
		return pegarPai(elemento.parentNode, pTagName);
}

function parser_ordena_data(tr){
	// esta fun��o deve analisar o objeto de entrada e escolher a fun��o de ordena��o de data adequada
	return ts_ordena_data;
}

function ts_ordena_data(a,b) {
	// formtao 'dd/MM/yyyy hh:mm'
    aa = ts_pegarTextoInterno(a.cells[INDICE_COLUNA_ORDENACAO]);
    bb = ts_pegarTextoInterno(b.cells[INDICE_COLUNA_ORDENACAO]);
    
    dt1 = (aa!="-")?aa.substr(6,4)+aa.substr(3,2)+aa.substr(0,2)+aa.substr(11,2)+aa.substr(14,2):"197001010000";
    dt2 = (bb!="-")?bb.substr(6,4)+bb.substr(3,2)+bb.substr(0,2)+bb.substr(11,2)+bb.substr(14,2):"197001010000";
    
    if (dt1==dt2) return 0;
    if (dt1<dt2) return -1;
    return 1;
}

function cdPatenteEB(str){
  if(str.substr(0,3).match("Mar") != null){
    return "Mar";
  }else if(str.substr(0,6).match("Gen Ex")!= null){
    return "Gen Ex";
  }else if(str.substr(0,7).match("Gen Div") != null){
    return "Gen Div";
  }else if(str.substr(0,7).match("Gen Bda") != null){
    return "Gen Bda";
  }else if(str.substr(0,3).match("Cel") != null){
    return "Cel";
  }else if(str.substr(0,2).match("TC") != null){
    return "TC";
  }else if(str.substr(0,3).match("Maj") != null){
    return "Maj";
  }else if(str.substr(0,3).match("Cap") != null){
    return "Cap";
  }else if(str.substr(0,6).match("1� Ten") != null){
    return "1� Ten";
  }else if(str.substr(0,6).match("2� Ten") != null){
    return "2� Ten";
  }else if(str.substr(0,3).match("Asp") != null){
    return "Asp";
  }else if(str.substr(0,2).match("ST") != null){
    return "ST";
  }else if(str.substr(0,6).match("1� Sgt") != null){
    return "1� Sgt";
  }else if(str.substr(0,6).match("2� Sgt") != null){
    return "2� Sgt";
  }else if(str.substr(0,6).match("3� Sgt") != null){
    return "3� Sgt";
  }else if(str.substr(0,2).match("Cb") != null){
    return "Cb";
  }else if(str.substr(0,2).match("Sd") != null){
    return "Sd";
  }else if(str.substr(0,4).match("TMor") != null){
    return "TMor";
  }else if(str.substr(0,2).match("T1") != null){
    return "T1";
  }else if(str.substr(0,2).match("T2") != null){
    return "T2";
  }else if(str.substr(0,2).match("SC") != null){
    return "SC";
  } else if(str.substr(0,5).match("indef") != null){
    return "-";
  }
  return str;
}

function cdPatenteFAB(str){
  if(str.substr(0,3).match("Mar" ) != null){
    return "Mar";
  }else if(str.substr(0,8).match("Ten Brig")!=null){
    return "Ten Brig";
  }else if(str.substr(0,8).match("Maj Brig") != null){
    return "Maj Brig";
  }else if(str.substr(0,4).match("Brig")!=null){
    return "Brig";
  }else if(str.substr(0,3).match("Cel") != null){
    return "Cel";
  }else if(str.substr(0,7).match("Ten Cel")!=null){
    return "Ten Cel";
  }else if(str.substr(0,3).match("Maj") != null){
    return "Maj";
  }else if(str.substr(0,3).match("Cap") != null){
    return "Cap";
  }else if(str.substr(0,6).match("1� Ten") != null){
    return "1� Ten";
  }else if(str.substr(0,6).match("2� Ten") != null){
    return "2� Ten";
  }else if(str.substr(0,3).match("Asp") != null){
    return "Asp";
  }else if(str.substr(0,2).match("SO")!=null){
    return "SO";
  }else if(str.substr(0,6).match("1� Sgt") != null){
    return "1� Sgt";
  }else if(str.substr(0,6).match("2� Sgt") != null){
    return "2� Sgt";
  }else if(str.substr(0,6).match("3� Sgt") != null){
    return "3� Sgt";
  }else if(str.substr(0,2).match("Cb") != null){
    return "Cb";
  }else if(str.substr(0,2).match("S1")!=null){
    return "S1";
  }else if(str.substr(0,2).match("TM")!=null){
    return "TM";
  }else if(str.substr(0,2).match("T1") != null){
    return "T1";
  }else if(str.substr(0,2).match("T2") != null){
    return "T2";
  }else if(str.substr(0,2).match("SC") != null){
    return "SC";
  } else if(str.substr(0,2).match("S2") != null){
    return "S2";
  } else if(str.substr(0,5).match("indef") != null){
    return "-";
  }
  return str;
}
	
function ts_ordena_patente(a,b){
	aa = ts_pegarTextoInterno(a.cells[INDICE_COLUNA_ORDENACAO]);
    bb = ts_pegarTextoInterno(b.cells[INDICE_COLUNA_ORDENACAO]);
    var patentes = new Array("Mar",
							 "Gen Ex",
							 "Gen Div",
							 "Gen Bda",
							 "Cel",
							 "TC",
							 "Maj",
							 "Cap",
							 "1� Ten",
							 "2� Ten",
							 "Asp",
							 "ST",
							 "1� Sgt",
							 "2� Sgt",
							 "3� Sgt",
							 "Cb",
							 "Sd",
							 "TMor",
							 "T1",
							 "T2",
							 "SC");
	var x;
	var y;
	//alert(cdPatenteEB(aa));
	for(var i=0; i<patentes.length; i++){
		if(cdPatenteEB(aa).match(patentes[i])!=null){
			// exce��o para tenente coronel
			if(cdPatenteEB(aa).match("TC")){
				x = 5;
			}else{
				x = i;
			}
		}
		if(cdPatenteEB(bb).match(patentes[i])!=null){
			// exce��o para tenente coronel
			if(cdPatenteEB(bb).match("TC")){
				y = 5;
			}else{
				y = i;
			}
		}
		if(typeof(x)!='undefined' && typeof(y)!='undefined') break;
	}
	return x-y;
}

function ts_ordena_numerico(a,b) { 
    aa = parseFloat(ts_pegarTextoInterno(a.cells[INDICE_COLUNA_ORDENACAO]));
    if (isNaN(aa)) aa = 0;
    bb = parseFloat(ts_pegarTextoInterno(b.cells[INDICE_COLUNA_ORDENACAO])); 
    if (isNaN(bb)) bb = 0;
    return aa-bb;
}

function ts_ordena_sem_caixa(a,b) {
    aa = ts_pegarTextoInterno(a.cells[INDICE_COLUNA_ORDENACAO]).toLowerCase();
    bb = ts_pegarTextoInterno(b.cells[INDICE_COLUNA_ORDENACAO]).toLowerCase();
    if (aa==bb) return 0;
    if (aa<bb) return -1;
    return 1;
}

function addEvent(elm, evType, fn, useCapture)
// addEvent and removeEvent
// cross-browser event handling for IE5+,  NS6 and Mozilla
// By Scott Andrew
{
  if (elm.addEventListener){
    elm.addEventListener(evType, fn, useCapture);
    return true;
  } else if (elm.attachEvent){
    var r = elm.attachEvent("on"+evType, fn);
    return r;
  } else {
    alert("Handler could not be removed");
  }
} 

function ordenaFAB(a,b) {
	aa = ts_pegarTextoInterno(a.cells[INDICE_COLUNA_ORDENACAO]);
    bb = ts_pegarTextoInterno(b.cells[INDICE_COLUNA_ORDENACAO]);
    var patentes = new Array("Mar",
    		"Ten Brig",
    		"Maj Brig",
    		"Brig",
    		"Cel",
    		"Ten Cel",
    		"Maj",
    		"Cap",
    		"1� Ten",
    		"2� Ten",
    		"Asp",
    		"SO",
    		"1� Sgt",
    		"2� Sgt",
    		"3� Sgt",
    		"Cb",
    		"S1",
    		"S2",
    		"TM",
    		"T1",
    		"T2",
    		"SC",
    		"-");
	var x;
	var y;
	for(var i=0; i<patentes.length; i++){
		if(cdPatenteFAB(aa).match(patentes[i])!=null){
			// exce��o para tenente coronel
			if(cdPatenteFAB(aa).match("Ten Cel")){
				x = 5;
			}else{
				x = i;
			}
		}
		if(cdPatenteFAB(bb).match(patentes[i])!=null){
			// exce��o para tenente coronel
			if(cdPatenteFAB(bb).match("Ten Cel")){
				y = 5;
			}else{
				y = i;
			}
		}
		if(typeof(x)!='undefined' && typeof(y)!='undefined') break;
	}
	return x-y;
}


