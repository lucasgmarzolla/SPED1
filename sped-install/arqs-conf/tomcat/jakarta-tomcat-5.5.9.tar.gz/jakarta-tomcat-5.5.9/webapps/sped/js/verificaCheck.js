function verificaCheck(form, checkbox) {
    if (typeof(form) == 'undefined'){
    	alert("� necess�rio passar um form para a fun��o verificaCheck");
    	return false;
    }
    if (typeof(checkbox) == 'undefined'){
    	alert("� necess�rio passar um checkbox para a fun��o verificaCheck");
    	return false;
    }
    
    var ok = false;
	if (checkbox.length){
		// Verifica se os checkboxes est�o marcados e pertencem ao mesmo form
	    for (var i=0;i<checkbox.length;i++) {
	    	if ((checkbox[i].checked) && (checkbox[i].form == form)) {
	        	ok = true;
	        	// Pelo menos um marcado j� � suficiente
	        	break;
			}
		}
	// Existe o checkbox, mas ele n�o possui length
	}else if ((checkbox.checked) && (checkbox.form == form)){
		ok = true;
	}
	
	if (!ok) {
    	alert('Por favor, selecione um documento de '+form.name+' para ser movido!');
	    return false;
    }
    return true;
}
