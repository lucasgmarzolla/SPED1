function viewAlert( sMsg, type ) {
	if( !type ) type = "success";
	var element = window.document.getElementById( "viewAlert" );
	element.className = type;
	element.innerHTML = sMsg;
}