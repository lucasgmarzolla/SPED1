// I18N constants

// LANG: "en", ENCODING: UTF-8 | ISO-8859-1
// Author: Mihai Bazon, <mishoo@infoiasi.ro>

// FOR TRANSLATORS:
//
//   1. PLEASE PUT YOUR CONTACT INFO IN THE ABOVE LINE
//      (at least a valid email address)
//
//   2. PLEASE TRY TO USE UTF-8 FOR ENCODING;
//      (if this is not possible, please include a comment
//       that states what encoding is necessary.)

HTMLArea.I18N = {

	// the following should be the filename without .js extension
	// it will be used for automatically load plugin language.
	lang: "en",

	tooltips: {
		bold:           "Negrito",
		italic:         "It�lico",
		underline:      "Sublinhado",
		strikethrough:  "Tachado",
		subscript:      "Subescrito",
		superscript:    "Sobrescrito",
		justifyleft:    "Alinhar � Esquerda",
		justifycenter:  "Centralizar",
		justifyright:   "Alinhar � Direita",
		justifyfull:    "Justificar",
		orderedlist:    "Lista Numerada",
		unorderedlist:  "Lista Marcadores",
		outdent:        "Diminuir Indenta��o",
		indent:         "Aumentar Indenta��o",
		forecolor:      "Cor da Fonte",
		hilitecolor:    "Cor do Fundo",
		horizontalrule: "Linha Horizontal",
		createlink:     "Inserir Link",
		insertimage:    "Inserir Imagem",
		inserttable:    "Inserir Tabela",
		htmlmode:       "Expandir Editor",
		popupeditor:    "Enlarge Editor",
		about:          "Sobre",
		showhelp:       "Ajuda",
		textindicator:  "Estilo Atual",
		undo:           "Desfaz sua �ltima a��o",
		redo:           "Refaz sua �ltima a��o",
		cut:            "Recortar",
		copy:           "Copiar",
		paste:          "Colar"	
	},

	buttons: {
		"ok":           "OK",
		"cancel":       "Cancelar"
	},

	msg: {
		"Path":         "Path",
		"TEXT_MODE":    "Voc� est� no m�dulo C�DIGO-FONTE.  Use o bot�o [<>] para mudar de volta para o WYSIWIG."
	}
};
